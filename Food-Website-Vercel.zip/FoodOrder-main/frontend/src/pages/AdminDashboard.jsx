import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChefHat, CheckSquare, Zap, Truck, LogOut, Package, TrendingUp } from 'lucide-react';
import axios from 'axios';
import AdminLogin from './AdminLogin';

const API_URL = 'https://foodorder-bxm6.onrender.com/api';

export default function AdminDashboard() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [completedTasks, setCompletedTasks] = useState(new Set());
  const [isReadyForDelivery, setIsReadyForDelivery] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [deliveryLoading, setDeliveryLoading] = useState(false);

  useEffect(() => {
    const authToken = localStorage.getItem('authToken');
    if (authToken) {
      setIsAuthenticated(true);
      fetchOrders();
      setInterval(fetchOrders, 10000);
    } else {
      setLoading(false);
    }
  }, []);

  const fetchOrders = async () => {
    setIsRefreshing(true);
    try {
      const res = await axios.get(`${API_URL}/orders`);
      setOrders(res.data);
    } catch (e) {}
    finally { setLoading(false); setIsRefreshing(false); }
  };

  const todayOrders = orders.filter(o => new Date(o.createdAt).toDateString() === new Date().toDateString());
  const pendingOrders = todayOrders.filter(o => o.status !== 'Delivered');

  // Aggregated Cooking Plan
  const cookingPlan = {};
  pendingOrders.forEach(order => {
    order.items.forEach(item => {
      cookingPlan[item.name] = (cookingPlan[item.name] || 0) + item.quantity;
    });
  });

  const tasks = Object.entries(cookingPlan);
  const allCookingDone = tasks.length > 0 && tasks.every(([name]) => completedTasks.has(name));

  if (!isAuthenticated) return <AdminLogin onLoginSuccess={() => { setIsAuthenticated(true); fetchOrders(); }} />;
  if (loading) return <div className="min-h-screen flex items-center justify-center font-black text-gray-300 text-2xl animate-pulse">KITCHEN...</div>;

  return (
    <div className="min-h-screen bg-gray-50 pb-40 font-sans">
      {/* Header */}
      <div className="bg-white border-b-4 border-gray-100 px-6 py-6 sticky top-0 z-50 flex justify-between items-center shadow-sm">
        <h1 className="text-3xl font-black text-gray-900 tracking-tight flex items-center gap-3 italic">
          <ChefHat className="text-orange-500" size={36} /> TIFFINFLOW CHEF
        </h1>
        <button onClick={() => { localStorage.clear(); window.location.reload(); }} className="p-3 bg-gray-100 text-gray-400 rounded-2xl hover:bg-red-50 hover:text-red-500 transition-all">
          <LogOut size={24} />
        </button>
      </div>

      <div className="max-w-2xl mx-auto px-6 py-12">
        
        {/* Aggregated List */}
        <section className="mb-12">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl font-black text-gray-900 uppercase tracking-widest">Cooking List</h2>
            <span className="px-4 py-1.5 bg-orange-100 text-orange-600 rounded-full font-black text-xs uppercase">
              {tasks.length} Dishes to Prep
            </span>
          </div>

          <div className="space-y-4">
            {tasks.length === 0 ? (
              <div className="py-32 text-center bg-white rounded-[40px] border-4 border-dashed border-gray-100">
                <Package size={64} className="mx-auto text-gray-200 mb-4" />
                <p className="text-2xl font-black text-gray-300 uppercase italic">No Orders Yet</p>
              </div>
            ) : tasks.map(([name, qty]) => {
              const isDone = completedTasks.has(name);
              return (
                <motion.div 
                  layout
                  key={name}
                  className={`bg-white p-6 rounded-[35px] shadow-lg shadow-gray-200/50 border-4 transition-all flex items-center justify-between ${isDone ? 'border-green-500 scale-95 opacity-50' : 'border-transparent'}`}>
                  <div className="flex items-center gap-6">
                    <div className={`w-20 h-20 rounded-[28px] flex items-center justify-center text-4xl font-black shadow-inner transition-colors ${isDone ? 'bg-green-500 text-white' : 'bg-orange-500 text-white'}`}>
                      {qty}
                    </div>
                    <div>
                      <h3 className={`text-2xl font-black tracking-tight ${isDone ? 'text-gray-400 line-through' : 'text-gray-900'}`}>{name}</h3>
                      <p className={`font-bold text-[10px] uppercase tracking-widest ${isDone ? 'text-green-500' : 'text-gray-400'}`}>
                        {isDone ? 'Cooking Complete' : 'Pending'}
                      </p>
                    </div>
                  </div>

                  <button 
                    onClick={() => {
                      const newSet = new Set(completedTasks);
                      if (isDone) newSet.delete(name);
                      else newSet.add(name);
                      setCompletedTasks(newSet);
                    }}
                    className={`px-8 py-4 rounded-2xl font-black text-sm transition-all border-b-4 uppercase tracking-widest ${isDone ? 'bg-gray-100 text-gray-400 border-gray-300' : 'bg-green-600 text-white border-green-800 active:border-b-0 active:translate-y-1'}`}>
                    {isDone ? 'Undo' : 'Mark Completed'}
                  </button>
                </motion.div>
              );
            })}
          </div>
        </section>

        {/* ── ACTION FOOTER ── */}
        <AnimatePresence>
          {allCookingDone && !isReadyForDelivery && (
            <motion.div initial={{ y: 100 }} animate={{ y: 0 }} exit={{ y: 100 }} className="fixed bottom-10 left-0 w-full px-6 flex justify-center z-50">
               <button 
                 onClick={() => setIsReadyForDelivery(true)}
                 className="w-full max-w-lg py-10 bg-gray-900 text-white rounded-[50px] font-black text-3xl shadow-2xl flex items-center justify-center gap-4 hover:bg-black hover:scale-105 transition-all border-b-[8px] border-gray-700 active:border-b-0 active:translate-y-2 uppercase tracking-tighter">
                 Mark Ready for Delivery <Zap size={36} className="text-orange-400 fill-orange-400" />
               </button>
            </motion.div>
          )}

          {isReadyForDelivery && (
            <motion.div initial={{ y: 0 }} className="fixed inset-0 bg-white/90 backdrop-blur-md z-[60] flex items-center justify-center p-6">
               <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} className="bg-white p-12 rounded-[60px] shadow-2xl border-4 text-center max-w-md w-full">
                 <Truck size={80} className="mx-auto text-blue-600 mb-6" />
                 <h2 className="text-4xl font-black mb-4 uppercase italic">Ready to Go?</h2>
                 <p className="text-gray-400 font-bold mb-10">Mark all today's orders as delivered.</p>

                 <button 
                   disabled={deliveryLoading}
                   onClick={async () => {
                      setDeliveryLoading(true);
                      const ids = pendingOrders.map(o => o._id);
                      try {
                        await axios.put(`${API_URL}/orders/batch/status`, { orderIds: ids, status: 'Delivered' });
                        setOrders(prev => prev.map(o => ids.includes(o._id) ? {...o, status: 'Delivered'} : o));
                        setCompletedTasks(new Set());
                        setIsReadyForDelivery(false);
                      } finally { setDeliveryLoading(false); }
                   }}
                   className="w-full py-8 bg-blue-600 text-white rounded-[40px] font-black text-3xl shadow-xl shadow-blue-900/30 active:scale-95 transition-all uppercase">
                   {deliveryLoading ? 'Saving...' : 'Mark Delivered'}
                 </button>
                 <button onClick={() => setIsReadyForDelivery(false)} className="mt-6 text-gray-400 font-black uppercase tracking-widest text-sm py-2">Go Back</button>
               </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ── DAILY SUMMARY (Chef's Business Agent View) ── */}
        <div className="mt-20 pt-10 border-t-4 border-dashed border-gray-100 pb-20">
          <div className="flex items-center gap-3 mb-6">
            <TrendingUp size={24} className="text-gray-400" />
            <h2 className="text-xl font-black text-gray-400 uppercase tracking-widest">Today's Business</h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            <div className="bg-white p-8 rounded-[40px] border-2 border-gray-50 shadow-sm">
              <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Orders Served</p>
              <h3 className="text-4xl font-black text-gray-900">{todayOrders.filter(o => o.status === 'Delivered').length}</h3>
            </div>
            
            <div className="bg-orange-50 p-8 rounded-[40px] border-2 border-orange-100 shadow-sm">
              <p className="text-[10px] font-black text-orange-400 uppercase tracking-widest mb-1">Total Revenue</p>
              <h3 className="text-4xl font-black text-orange-600">₹{todayOrders.filter(o => o.status === 'Delivered').reduce((s,o) => s + o.totalAmount, 0)}</h3>
            </div>

            <div className="bg-green-50 p-8 rounded-[40px] border-2 border-green-100 shadow-sm">
              <p className="text-[10px] font-black text-green-400 uppercase tracking-widest mb-1">Estimated Profit</p>
              <h3 className="text-4xl font-black text-green-600">₹{(todayOrders.filter(o => o.status === 'Delivered').reduce((s,o) => s + o.totalAmount, 0) * 0.4).toFixed(0)}</h3>
            </div>
          </div>
          
          <div className="mt-8 text-center text-[10px] font-black text-gray-300 uppercase tracking-[0.3em]">
            Syncing with Business Agent Email (9:00 PM)
          </div>
        </div>

      </div>
    </div>
  );
}

