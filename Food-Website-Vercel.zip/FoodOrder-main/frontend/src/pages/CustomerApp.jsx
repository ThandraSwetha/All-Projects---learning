import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ShoppingBag, Plus, Minus, CheckCircle, CreditCard, ChevronRight, X, Star, Flame, Mic, Sparkles, MapPin, CalendarDays, Bike, PackageOpen, HeartHandshake, ChefHat as ChefHatIcon, ShieldCheck, MessageCircle, QrCode, DollarSign } from 'lucide-react';
import axios from 'axios';
import confetti from 'canvas-confetti';
import WhatsAppAssistant from '../components/WhatsAppAssistant';

const API_URL = 'https://foodorder-bxm6.onrender.com/api';

export default function CustomerApp() {
  const [menuItems, setMenuItems] = useState([]);
  const [cart, setCart] = useState([]);
  const [isCheckout, setIsCheckout] = useState(false);
  const [isPayment, setIsPayment] = useState(false);
  const [orderComplete, setOrderComplete] = useState(false);
  const [loading, setLoading] = useState(true);
  const [customerInfo, setCustomerInfo] = useState({ name: localStorage.getItem('customerName') || '', phone: localStorage.getItem('customerPhone') || '', address: '' });
  const [currentOrder, setCurrentOrder] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [isCustomerLoggedIn, setIsCustomerLoggedIn] = useState(!!localStorage.getItem('customerName'));
  const [loginName, setLoginName] = useState('');
  const [loginPhone, setLoginPhone] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [liveStatus, setLiveStatus] = useState('New');
  const [aiRecommendations, setAiRecommendations] = useState([]);
  const [showWASidebar, setShowWASidebar] = useState(false);
  const CATEGORIES = ['All', 'Tiffins', 'Meals', 'Rice'];

  useEffect(() => {
    fetchMenu();
    // Simulate AI Prediction based on past 'history'
    if (localStorage.getItem('customerName')) {
      setAiRecommendations(['Dosa', 'Biryani']); 
    }
  }, []);

  // Live Tracking Poller
  useEffect(() => {
    let interval;
    if (orderComplete && currentOrder) {
      interval = setInterval(async () => {
        try {
          const res = await axios.get(`${API_URL}/orders`);
          const active = res.data.find(o => o._id === currentOrder._id);
          if (active) setLiveStatus(active.status);
        } catch(e){}
      }, 5000);
    }
    return () => clearInterval(interval);
  }, [orderComplete, currentOrder]);

  const handleVoiceOrder = () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) return alert("Browser doesn't support voice ordering. Safari/Chrome required.");
    const recognition = new SpeechRecognition();
    recognition.onstart = () => setIsListening(true);
    recognition.onresult = (e) => {
      const transcript = e.results[0][0].transcript.toLowerCase();
      let found = false;
      menuItems.forEach(item => {
        if (transcript.includes(item.name.toLowerCase())) {
          addToCart(item);
          found = true;
        }
      });
      setIsListening(false);
      if(found) alert(`Added your voice order to cart!`);
      else alert(`Couldn't find an item matching: "${transcript}"`);
    };
    recognition.onerror = () => setIsListening(false);
    recognition.start();
  };

  const handleLogin = (e) => {
    e.preventDefault();
    if(loginName && loginPhone) {
      localStorage.setItem('customerName', loginName);
      localStorage.setItem('customerPhone', loginPhone);
      setCustomerInfo({...customerInfo, name: loginName, phone: loginPhone});
      setIsCustomerLoggedIn(true);
    }
  };

  const fetchMenu = async () => {
    try {
      const res = await axios.get(`${API_URL}/menu-items`);
      setMenuItems(res.data);
    } catch (error) {
      console.error('Error fetching menu:', error);
    } finally {
      setLoading(false);
    }
  };

  const addToCart = (item) => {
    setCart((prev) => {
      const exists = prev.find((i) => i._id === item._id);
      if (exists) {
        return prev.map((i) => (i._id === item._id ? { ...i, qty: i.qty + 1 } : i));
      }
      return [...prev, { ...item, qty: 1 }];
    });
  };

  const removeFromCart = (id) => {
    setCart((prev) => {
      return prev.map((i) => {
        if (i._id === id) {
          return { ...i, qty: Math.max(0, i.qty - 1) };
        }
        return i;
      }).filter((i) => i.qty > 0);
    });
  };

  const cartTotal = cart.reduce((sum, item) => sum + (item.price * item.qty), 0);
  const cartCount = cart.reduce((sum, item) => sum + item.qty, 0);

  const handleCheckoutSubmit = async (e) => {
    e.preventDefault();
    try {
      const orderData = {
        customerName: customerInfo.name,
        phone: customerInfo.phone,
        address: customerInfo.address,
        items: cart.map(i => ({ name: i.name, quantity: i.qty })),
        totalAmount: cartTotal,
        source: 'Web',
        paymentStatus: 'Pending'
      };
      const res = await axios.post(`${API_URL}/orders`, orderData);
      setCurrentOrder(res.data);
      setIsCheckout(false);
      setIsPayment(true);
    } catch (error) {
      console.error('Order creation failed', error);
      alert('Failed to place order. Please try again.');
    }
  };

  const simulatePayment = async () => {
    if (!currentOrder) return;
    try {
      await axios.put(`${API_URL}/orders/${currentOrder._id}`, {
        paymentStatus: 'Paid' // Note: This sets paymentStatus
      });
      // Also might need to update status separately if the backend defaults to New
      setIsPayment(false);
      setOrderComplete(true);
      confetti({
        particleCount: 150,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#ff7a00', '#ffffff', '#4caf50']
      });
      setCart([]);
    } catch (error) {
      console.error('Payment failed', error);
      alert('Payment simulation failed.');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-4rem)]">
        <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-solid" style={{ borderColor: '#e23744' }}></div>
      </div>
    );
  }

  if (!isCustomerLoggedIn) {
    return (
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center bg-gray-50 px-4 py-12">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="max-w-md w-full bg-white rounded-[2rem] shadow-2xl p-8 border border-gray-100">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-black text-gray-900 mb-2">tiffin<span className="text-orange-500">flow</span></h1>
            <p className="text-gray-500 font-medium">Please login or register to continue</p>
          </div>
          <form onSubmit={handleLogin} className="space-y-5">
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">Full Name</label>
              <input required type="text" value={loginName} onChange={(e) => setLoginName(e.target.value)} className="w-full px-5 py-4 rounded-xl border border-gray-200 focus:border-orange-500 focus:ring-4 focus:ring-orange-500/20 outline-none transition-all text-lg" placeholder="e.g. Rahul Sharma" />
            </div>
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">Phone Number</label>
              <input required type="tel" value={loginPhone} onChange={(e) => setLoginPhone(e.target.value)} className="w-full px-5 py-4 rounded-xl border border-gray-200 focus:border-orange-500 focus:ring-4 focus:ring-orange-500/20 outline-none transition-all text-lg" placeholder="10-digit mobile number" />
            </div>
            <button type="submit" className="w-full mt-2 py-4 bg-gradient-to-r from-orange-500 to-yellow-500 text-white rounded-xl font-bold text-xl hover:shadow-lg hover:shadow-orange-500/40 hover:-translate-y-1 transition-all">
              Continue
            </button>
          </form>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12 relative">
      
      {/* Hero Section */}
      {!isCheckout && !isPayment && !orderComplete && (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative rounded-[2rem] overflow-hidden mb-16 shadow-2xl h-[400px] flex items-center justify-center text-center group"
        >
          <div className="absolute inset-0 bg-black/40 group-hover:bg-black/50 transition-colors z-10 duration-700"></div>
          <img 
            src="https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=1600&q=80" 
            alt="Hero Background" 
            className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-[1.5s]"
          />
          <div className="relative z-20 px-4 w-full max-w-4xl">
            <motion.span 
              initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
              className="bg-white/20 backdrop-blur-md text-white border border-white/30 px-5 py-2 rounded-full text-sm font-bold mb-6 inline-flex items-center gap-2 uppercase tracking-wider"
            >
              <HeartHandshake size={16} className="text-orange-300" /> Support Local Home Cooks
            </motion.span>
            <motion.h1 
              initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
              className="text-5xl md:text-7xl font-black text-white mb-6 tracking-tight drop-shadow-xl"
            >
              Made with Love <br className="hidden md:block" />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-yellow-300">
                By Mrs. Sharma
              </span>
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
              className="text-gray-100 max-w-2xl mx-auto text-lg md:text-xl font-medium drop-shadow-md mb-8"
            >
              "Cooking traditional Tamil and Telugu recipes passed down for 3 generations. My specialty is the Guntur Biryani and crispy Masala Dosa! Every meal is prepared in my hygienic home kitchen."
            </motion.p>
            <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.4 }} className="flex flex-wrap justify-center gap-4">
              <div className="bg-white/10 backdrop-blur-md border border-white/20 px-4 py-2 rounded-xl flex items-center gap-2 text-white font-medium"><ChefHatIcon size={18} className="text-orange-400"/> 15 Yrs Experience</div>
              <div className="bg-white/10 backdrop-blur-md border border-white/20 px-4 py-2 rounded-xl flex items-center gap-2 text-white font-medium"><ShieldCheck size={18} className="text-green-400"/> FSSAI Registered</div>
            </motion.div>
          </div>
        </motion.div>
      )}

      {/* Main Content Area */}
      <div className="flex flex-col lg:flex-row gap-8 relative">
        <div className={`flex-1 transition-all duration-500 ease-in-out ${isCheckout || isPayment || orderComplete ? 'w-full' : 'lg:w-2/3'}`}>
          
          {/* Menu View */}
          {!isCheckout && !isPayment && !orderComplete && (
            <>
            {/* Advanced Features Top Bar */}
            <div className="mb-10 space-y-6">
              
              {/* Voice Order & Subscription Banner Rows */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <button 
                  onClick={handleVoiceOrder}
                  className={`flex items-center justify-center gap-3 p-6 rounded-3xl border-2 transition-all ${isListening ? 'bg-orange-50 border-orange-500 animate-pulse text-orange-600' : 'bg-white border-gray-100 hover:border-orange-300 text-gray-700 shadow-sm'}`}
                >
                  <div className={`p-3 rounded-full ${isListening ? 'bg-orange-500 text-white' : 'bg-gray-100 text-gray-600'}`}>
                    <Mic size={24} />
                  </div>
                  <div className="text-left">
                    <h3 className="font-bold text-lg">{isListening ? 'Listening...' : 'Voice Ordering'}</h3>
                    <p className="text-sm opacity-80">Tap & say "1 dosa"</p>
                  </div>
                </button>

                <div className="flex flex-col justify-center gap-2 p-6 rounded-3xl border border-gray-100 bg-gradient-to-br from-green-50 to-emerald-50 relative overflow-hidden group">
                  <div className="absolute right-0 top-0 opacity-10 transform translate-x-4 -translate-y-4 group-hover:scale-110 transition-transform"><CalendarDays size={100} /></div>
                  <h3 className="font-bold text-lg text-green-800 flex items-center gap-2"><CalendarDays size={20}/> Tiffin Subscriptions</h3>
                  <p className="text-sm text-green-700 font-medium">Monthly Lunch Plan • ₹3000</p>
                  <button className="mt-1 bg-green-600 text-white text-sm font-bold py-2 px-4 rounded-xl w-max hover:bg-green-700 shadow-md">Subscribe Now</button>
                </div>
              </div>

              {/* AI Recommendations */}
              {aiRecommendations.length > 0 && menuItems.filter(i => aiRecommendations.includes(i.name)).length > 0 && (
                <div className="bg-gradient-to-br from-purple-50 to-fuchsia-50 rounded-3xl p-6 border border-purple-100 relative">
                  <h2 className="text-xl font-black text-purple-900 mb-4 flex items-center gap-2">
                    <Sparkles className="text-purple-600" size={24} /> Recommended For You
                  </h2>
                  <div className="flex gap-4 overflow-x-auto pb-2 custom-scrollbar">
                    {menuItems.filter(i => aiRecommendations.includes(i.name)).map(item => (
                      <div key={`ai-${item._id}`} className="bg-white rounded-2xl p-4 flex gap-4 min-w-[280px] shadow-sm border border-purple-100/50 hover:shadow-md transition-shadow">
                        <img src={item.image || `https://placehold.co/400x300/ff7a00/ffffff?text=${item.name.replace(/ /g, '+')}`} alt={item.name} className="w-20 h-20 rounded-xl object-cover" />
                        <div className="flex flex-col justify-between flex-1">
                          <div>
                            <h4 className="font-bold text-gray-900">{item.name}</h4>
                            <p className="text-xs text-purple-600 font-bold bg-purple-100 px-2 py-0.5 rounded w-max mt-1">Based on history</p>
                          </div>
                          <div className="flex justify-between items-center mt-2">
                            <span className="font-bold text-gray-900">₹{item.price}</span>
                            <button onClick={() => addToCart(item)} className="bg-purple-600 text-white p-1.5 rounded-lg hover:bg-purple-700"><Plus size={16}/></button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Trending Section */}
            {menuItems.filter(i => i.trending).length > 0 && selectedCategory === 'All' && (
              <div className="mb-14">
                <h2 className="text-2xl font-black text-gray-900 mb-6 flex items-center gap-2">
                  <Flame className="text-orange-500" size={28} /> Trending Dishes
                </h2>
                <div className="flex gap-6 overflow-x-auto pb-6 custom-scrollbar snap-x">
                  {menuItems.filter(i => i.trending).map((item, idx) => {
                    const cartItem = cart.find(i => i._id === item._id);
                    const qty = cartItem ? cartItem.qty : 0;
                    return (
                      <motion.div 
                        key={`trending-${item._id}`}
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: idx * 0.1 }}
                        className="min-w-[300px] sm:min-w-[340px] snap-start glass-card rounded-[2rem] overflow-hidden hover:shadow-2xl hover:shadow-orange-500/10 transition-all duration-300 group relative bg-white flex flex-col"
                      >
                        <div className="relative w-full h-48 overflow-hidden bg-gradient-to-br from-orange-50 to-amber-100">
                          <img 
                            src={item.image} 
                            alt={item.name}
                            loading="lazy"
                            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-[1.5s]"
                            onError={(e) => { 
                              e.target.style.display = 'none';
                              e.target.parentNode.querySelector('.emoji-fallback').style.display = 'flex';
                            }}
                          />
                          <div className="emoji-fallback w-full h-full hidden absolute inset-0 bg-gradient-to-br from-orange-100 via-amber-100 to-yellow-50 items-center justify-center flex-col gap-2">
                            <span className="text-7xl">{item.emoji || '🍛'}</span>
                            <span className="font-bold text-orange-700 text-sm">{item.name}</span>
                          </div>
                          <div className="absolute top-3 left-3 bg-white/90 backdrop-blur-md px-2.5 py-1 rounded-lg flex items-center gap-1 shadow-lg">
                            <Star size={14} className="text-yellow-500 fill-yellow-500" />
                            <span className="text-sm font-bold text-gray-800">{item.rating || 4.5}</span>
                          </div>
                          <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-md px-3 py-1 rounded-full shadow-lg">
                            <span className="text-lg font-bold text-gray-900">₹{item.price}</span>
                          </div>
                        </div>
                        <div className="p-5 flex flex-col flex-grow">
                          <h3 className="text-xl font-bold text-gray-800 mb-1">{item.name}</h3>
                          <p className="text-sm text-gray-500 line-clamp-2 mb-4 flex-grow">{item.description}</p>
                          {qty === 0 ? (
                            <button 
                              onClick={() => addToCart(item)}
                              className="w-full py-3 rounded-2xl bg-gradient-to-r from-orange-500 to-yellow-500 text-white font-bold hover:shadow-lg hover:-translate-y-1 transition-all duration-300 flex items-center justify-center gap-2 group/btn"
                            >
                              <Plus size={18} className="group-hover/btn:rotate-90 transition-transform" />
                              Add
                            </button>
                          ) : (
                            <div className="flex items-center justify-between bg-orange-500 rounded-2xl p-1 shadow-inner shadow-black/10">
                              <button onClick={() => removeFromCart(item._id)} className="w-10 h-10 flex items-center justify-center bg-white/20 text-white rounded-xl hover:bg-white hover:text-orange-600 transition-colors">
                                <Minus size={20} />
                              </button>
                              <span className="text-white font-bold text-lg">{qty}</span>
                              <button onClick={() => addToCart(item)} className="w-10 h-10 flex items-center justify-center bg-white text-orange-600 rounded-xl hover:bg-orange-50 transition-colors">
                                <Plus size={20} />
                              </button>
                            </div>
                          )}
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              </div>
            )}

            <h2 className="text-2xl font-black text-gray-900 mb-6">Explore Menu</h2>
            <div className="flex gap-4 overflow-x-auto pb-4 mb-8 custom-scrollbar">
              {CATEGORIES.map(cat => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-6 py-2.5 rounded-full font-bold text-sm transition-all whitespace-nowrap border ${selectedCategory === cat ? 'bg-gray-900 text-white border-gray-900 shadow-md transform scale-105' : 'bg-white text-gray-600 border-gray-200 hover:border-gray-900 hover:text-gray-900'}`}
                >
                  {cat}
                </button>
              ))}
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">
              <AnimatePresence>
                {(selectedCategory === 'All' ? menuItems : menuItems.filter(i => i.category === selectedCategory)).map((item, idx) => {
                  const cartItem = cart.find(i => i._id === item._id);
                  const qty = cartItem ? cartItem.qty : 0;
                  return (
                    <motion.div 
                      key={item._id}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: idx * 0.05 }}
                      className="glass-card rounded-3xl overflow-hidden hover:shadow-2xl hover:shadow-primary/10 transition-all duration-300 group relative bg-white flex flex-col h-full"
                    >
                      <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-bl-full -z-10 group-hover:scale-110 transition-transform"></div>
                      
                      {/* Food Image */}
                      <div className="relative w-full h-48 overflow-hidden bg-gradient-to-br from-orange-50 to-amber-100">
                        <img 
                          src={item.image} 
                          alt={item.name}
                          loading="lazy"
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                          onError={(e) => { 
                            e.target.style.display = 'none';
                            e.target.parentNode.querySelector('.emoji-fallback').style.display = 'flex';
                          }}
                        />
                        <div className="emoji-fallback w-full h-full hidden absolute inset-0 bg-gradient-to-br from-orange-100 via-amber-100 to-yellow-50 items-center justify-center flex-col gap-2">
                          <span className="text-7xl">{item.emoji || '🍛'}</span>
                          <span className="font-bold text-orange-700 text-sm">{item.name}</span>
                        </div>
                        <div className="absolute top-3 left-3 bg-white/90 backdrop-blur-md px-2.5 py-1 rounded-lg flex items-center gap-1 shadow-lg">
                          <Star size={14} className="text-yellow-500 fill-yellow-500" />
                          <span className="text-sm font-bold text-gray-800">{item.rating || (4 + Math.random()).toFixed(1)}</span>
                        </div>
                        <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-md px-3 py-1 rounded-full shadow-lg">
                          <span className="text-lg font-bold text-gray-900">₹{item.price}</span>
                        </div>
                      </div>

                      {/* Item Details */}
                      <div className="p-5 flex flex-col flex-grow">
                        <h3 className="text-xl font-bold text-gray-800 mb-1">{item.name}</h3>
                        <p className="text-sm text-gray-500 line-clamp-2 mb-4 flex-grow">{item.description}</p>
                        
                        {qty === 0 ? (
                          <button 
                            onClick={() => addToCart(item)}
                            className="w-full py-3 rounded-2xl bg-gradient-to-r from-primary to-orange-400 text-white font-semibold hover:shadow-lg hover:-translate-y-1 transition-all duration-300 flex items-center justify-center gap-2 group/btn"
                          >
                            <Plus size={18} className="group-hover/btn:rotate-90 transition-transform" />
                            Add to Cart
                          </button>
                        ) : (
                          <div className="flex items-center justify-between bg-primary rounded-2xl p-1 shadow-inner shadow-black/10">
                            <button 
                              onClick={() => removeFromCart(item._id)}
                              className="w-10 h-10 flex items-center justify-center bg-white/20 text-white rounded-xl hover:bg-white hover:text-primary transition-colors focus:ring-2 focus:ring-white/50"
                            >
                              <Minus size={20} />
                            </button>
                          <span className="text-white font-bold text-lg">{qty}</span>
                          <button 
                            onClick={() => addToCart(item)}
                            className="w-10 h-10 flex items-center justify-center bg-white text-primary rounded-xl hover:bg-orange-50 transition-colors shadow-sm focus:ring-2 focus:ring-white/50"
                          >
                            <Plus size={20} />
                          </button>
                        </div>
                      )}
                      </div>
                    </motion.div>
                  );
                })}
              </AnimatePresence>
            </div>
            </>
          )}

          {/* Checkout View */}
          {isCheckout && !isPayment && !orderComplete && (
            <motion.div 
              initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}
              className="max-w-2xl mx-auto glass-card rounded-3xl p-8 bg-white"
            >
              <div className="flex items-center gap-4 mb-8">
                <button onClick={() => setIsCheckout(false)} className="text-gray-400 hover:text-gray-700 bg-gray-50 p-2 rounded-full">
                  <ChevronRight className="rotate-180" />
                </button>
                <h2 className="text-3xl font-bold text-gray-800">Checkout</h2>
              </div>

              <form onSubmit={handleCheckoutSubmit} className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
                  <input required
                    type="text" 
                    value={customerInfo.name}
                    onChange={(e) => setCustomerInfo({...customerInfo, name: e.target.value})}
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all outline-none"
                    placeholder="Enter your name"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Phone Number</label>
                  <input required
                    type="tel" 
                    value={customerInfo.phone}
                    onChange={(e) => setCustomerInfo({...customerInfo, phone: e.target.value})}
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all outline-none"
                    placeholder="Enter 10-digit number"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Delivery Address</label>
                  <textarea required
                    rows="3"
                    value={customerInfo.address}
                    onChange={(e) => setCustomerInfo({...customerInfo, address: e.target.value})}
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all outline-none resize-none"
                    placeholder="Enter complete delivery address"
                  />
                </div>
                
               <div className="pt-6 border-t border-gray-100 flex justify-between items-center">
                  <div>
                    <p className="text-sm text-gray-500">Total to pay</p>
                    <p className="text-3xl font-extrabold" style={{color:'#e23744'}}>₹{cartTotal}</p>
                  </div>
                  <button type="submit"
                    className="px-8 py-4 text-white rounded-2xl font-bold text-lg hover:-translate-y-1 transition-all shadow-lg"
                    style={{background:'linear-gradient(135deg,#e23744,#ff7a00)', boxShadow:'0 8px 24px rgba(226,55,68,.35)'}}
                  >
                    Proceed to Pay →
                  </button>
                </div>
              </form>
            </motion.div>
          )}

          {/* Payment Simulation View */}
          {isPayment && !orderComplete && currentOrder && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}
              className="max-w-md mx-auto glass-card rounded-3xl p-8 bg-white text-center shadow-2xl overflow-hidden relative"
            >
              <div className="absolute top-0 left-0 w-full h-2 bg-orange-500"></div>
              <h2 className="text-3xl font-black text-gray-900 mb-2">Payment</h2>
              <div className="bg-gray-50 p-4 rounded-2xl mb-8">
                <p className="text-gray-400 font-bold text-xs uppercase tracking-widest">Amount to Pay</p>
                <div className="text-4xl font-black text-gray-900">₹{currentOrder.totalAmount}</div>
              </div>
              
              <div className="space-y-4">
                {/* QR Scanner Option */}
                <button 
                  onClick={simulatePayment}
                  className="w-full p-6 border-4 border-gray-100 rounded-[35px] hover:border-blue-500 hover:bg-blue-50 transition-all group flex flex-col items-center gap-4 text-center"
                >
                  <div className="w-40 h-40 bg-white border-2 border-gray-100 rounded-3xl p-3 flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform">
                    <QrCode size={120} className="text-blue-600" strokeWidth={1.5} />
                  </div>
                  <div>
                    <h3 className="text-xl font-black text-gray-800 uppercase tracking-tighter">PhonePe / Google Pay</h3>
                    <p className="text-xs font-bold text-gray-400">Scan QR Code to Pay Fast</p>
                  </div>
                </button>

                {/* COD Option */}
                <button 
                  onClick={simulatePayment}
                  className="w-full p-6 border-4 border-gray-100 rounded-[35px] hover:border-green-500 hover:bg-green-50 transition-all flex items-center justify-center gap-4"
                >
                  <div className="w-14 h-14 bg-green-100 text-green-600 rounded-2xl flex items-center justify-center">
                    <DollarSign size={32} />
                  </div>
                  <div className="text-left">
                    <h3 className="text-xl font-black text-gray-800 uppercase tracking-tighter">Cash on Delivery</h3>
                    <p className="text-xs font-bold text-gray-400">Pay at your doorstep</p>
                  </div>
                </button>
              </div>

              <div className="mt-8">
                <p className="text-[10px] text-gray-300 font-black uppercase tracking-[0.2em]">100% Safe & Secure Payments</p>
              </div>
            </motion.div>
          )}

          {/* Order Completed / Live Tracker View */}
          {orderComplete && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}
              className="max-w-2xl mx-auto glass-card rounded-3xl p-8 bg-white shadow-2xl"
            >
              <div className="text-center mb-10">
                <div className="inline-flex items-center justify-center w-20 h-20 bg-green-50 text-green-500 rounded-full mb-4">
                  <CheckCircle size={40} />
                </div>
                <h2 className="text-3xl font-extrabold text-gray-900 mb-2">Order Confirmed!</h2>
                <p className="text-gray-500 text-lg font-medium">Tracking Order #{currentOrder?._id?.substring(0,8).toUpperCase()}</p>
              </div>
              
              {/* Live Tracker Stepper */}
              <div className="bg-gray-50 rounded-3xl p-8 border border-gray-100 mb-10 relative overflow-hidden">
                <div className="absolute top-1/2 left-10 right-10 h-1 bg-gray-200 -z-10 -translate-y-1/2"></div>
                
                {(() => {
                  const stages = ['New', 'Preparing', 'Out for Delivery', 'Completed'];
                  const currentIndex = stages.indexOf(liveStatus);
                  const progressBarWidth = currentIndex === -1 ? 0 : (currentIndex / (stages.length - 1)) * 100;
                  
                  return (
                    <div className="relative z-10 w-full">
                      <div className="absolute top-1/2 left-0 h-1 bg-green-500 -z-10 -translate-y-1/2 transition-all duration-1000 ease-in-out" style={{ width: `${progressBarWidth}%` }}></div>
                      
                      <div className="flex justify-between relative">
                        {stages.map((stage, idx) => {
                          const isDone = currentIndex >= idx;
                          const isCurrent = currentIndex === idx;
                          let Icon = PackageOpen;
                          if (stage === 'Preparing') Icon = Flame;
                          if (stage === 'Out for Delivery') Icon = Bike;
                          if (stage === 'Completed') Icon = CheckCircle;
                          
                          return (
                            <div key={stage} className="flex flex-col items-center flex-1 relative">
                              <div className={`w-12 h-12 md:w-16 md:h-16 rounded-full flex mx-auto items-center justify-center transition-all duration-500 ${isDone ? 'bg-green-500 text-white shadow-lg shadow-green-500/40' : 'bg-white border-2 border-gray-200 text-gray-400'} ${isCurrent ? 'scale-110 md:scale-125 ring-4 ring-green-100' : ''}`}>
                                <Icon size={24} className={isCurrent ? 'animate-bounce' : ''} />
                              </div>
                              <span className={`mt-3 md:mt-4 text-[10px] md:text-sm font-bold text-center leading-tight ${isDone ? 'text-gray-900' : 'text-gray-400'}`}>{stage}</span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  );
                })()}
              </div>

              <div className="grid grid-cols-2 gap-4 mb-8">
                <div className="bg-gray-50 p-4 rounded-2xl border border-gray-100">
                  <span className="text-gray-500 text-sm block mb-1">Total Paid</span>
                  <span className="font-bold text-gray-900 text-lg">₹{currentOrder?.totalAmount}</span>
                </div>
                <div className="bg-gray-50 p-4 rounded-2xl border border-gray-100">
                  <span className="text-gray-500 text-sm block mb-1">Delivery to</span>
                  <span className="font-bold text-gray-900 text-sm truncate block">{currentOrder?.address}</span>
                </div>
              </div>

              <button 
                onClick={() => window.location.reload()}
                className="w-full py-4 bg-gray-900 text-white rounded-2xl font-bold text-lg hover:bg-black transition-colors shadow-xl"
              >
                Back to Menu
              </button>
            </motion.div>
          )}

        </div>

        {/* ── Floating Cart FAB (always visible when cart has items) ── */}
        {!isCheckout && !isPayment && !orderComplete && cart.length > 0 && (
          <div className="fixed bottom-6 left-0 right-0 z-50 flex justify-center px-4 lg:hidden">
            <button
              onClick={() => setIsCheckout(true)}
              className="flex items-center gap-4 px-6 py-4 rounded-2xl text-white font-bold text-base shadow-2xl w-full max-w-md"
              style={{ background: 'linear-gradient(135deg, #e23744, #ff7a00)' }}
            >
              <div className="bg-white/20 p-2 rounded-xl">
                <ShoppingBag size={22} />
              </div>
              <span className="flex-1 text-left">{cartCount} item{cartCount > 1 ? 's' : ''} in cart</span>
              <span className="font-black text-xl">₹{cartTotal}</span> 
              <ChevronRight size={20} />
            </button>
          </div>
        )}

        {/* ── Sidebar Cart (Desktop sticky) ── */}
        {!isCheckout && !isPayment && !orderComplete && cart.length > 0 && (
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="lg:w-1/3 xl:w-1/4 fixed lg:sticky bottom-0 lg:bottom-auto lg:top-24 left-0 right-0 z-40 bg-white lg:bg-transparent border-t lg:border-none border-gray-200"
          >
            <div className="glass-card lg:rounded-3xl p-6 shadow-2xl max-h-[60vh] lg:max-h-[calc(100vh-8rem)] flex flex-col">
              <div className="flex items-center gap-3 mb-5 pb-4 border-b border-gray-100">
                <div className="p-3 rounded-full" style={{background:'rgba(226,55,68,.10)'}}>
                  <ShoppingBag size={24} style={{color:'#e23744'}} />
                </div>
                <div>
                  <h2 className="text-xl font-extrabold text-gray-900">Your Cart</h2>
                  <p className="text-sm text-gray-500">{cartCount} item{cartCount>1?'s':''} selected</p>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto pr-2 space-y-4 mb-6">
                {cart.map(item => (
                    <div key={item._id} className="flex justify-between items-center group">
                      <div className="flex items-center gap-3">
                        <div className="relative w-12 h-12 rounded-xl overflow-hidden bg-orange-50 flex-shrink-0 shadow-sm flex items-center justify-center">
                          <img 
                            src={item.image} 
                            alt={item.name}
                            className="w-full h-full object-cover"
                            onError={(e) => { e.target.style.display='none'; e.target.parentNode.querySelector('.cart-emoji').style.display='flex'; }}
                          />
                          <span className="cart-emoji hidden absolute inset-0 items-center justify-center text-2xl">{item.emoji || '🍛'}</span>
                        </div>
                        <div>
                          <p className="font-semibold text-gray-800 text-sm">{item.name}</p>
                          <p className="text-xs font-medium" style={{color:'#e23744'}}>₹{item.price}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 bg-gray-50 rounded-xl p-1 border border-gray-100">
                        <button onClick={() => removeFromCart(item._id)} className="p-1.5 text-gray-400 hover:text-red-500 transition-colors rounded-lg hover:bg-red-50"><Minus size={14} /></button>
                        <span className="text-sm font-bold w-5 text-center">{item.qty}</span>
                        <button onClick={() => addToCart(item)} className="p-1.5 text-gray-400 transition-colors rounded-lg hover:bg-green-50" style={{'--hover-color':'#3ab757'}} onMouseEnter={e=>e.currentTarget.style.color='#3ab757'} onMouseLeave={e=>e.currentTarget.style.color=''}><Plus size={14} /></button>
                      </div>
                    </div>
                ))}
              </div>

              <div className="mt-auto pt-4 border-t border-gray-100">
                <div className="flex justify-between items-center mb-4">
                  <span className="text-gray-500 font-medium">Total</span>
                  <span className="text-2xl font-black text-gray-900">₹{cartTotal}</span>
                </div>
                <button 
                  onClick={() => setIsCheckout(true)}
                  className="w-full py-4 text-white rounded-2xl font-bold text-lg shadow-lg hover:-translate-y-0.5 transition-all flex items-center justify-center gap-2"
                  style={{background:'linear-gradient(135deg,#e23744,#ff7a00)', boxShadow:'0 8px 24px rgba(226,55,68,.35)'}}
                >
                  Checkout <ChevronRight size={20} />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </div>
      {/* ── WhatsApp Floating Button ── */}
      <div className="fixed bottom-24 right-6 z-[60]">
        <button
          onClick={() => setShowWASidebar(true)}
          className="flex items-center gap-2 p-4 rounded-full bg-green-500 text-white shadow-2xl hover:bg-green-600 transition-all hover:scale-110 active:scale-95"
        >
          <MessageCircle size={28} />
          <span className="font-bold hidden sm:inline">Order via Assistant</span>
        </button>
      </div>

      {/* ── WhatsApp Sidebar/Overlay ── */}
      <AnimatePresence>
        {showWASidebar && (
          <div className="fixed inset-0 z-[100] flex justify-end">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setShowWASidebar(false)} className="absolute inset-0 bg-black/40 backdrop-blur-sm" />
            <motion.div initial={{ x: '100%' }} animate={{ x: 0 }} exit={{ x: '100%' }} className="relative w-full max-w-md h-full bg-white shadow-2xl flex flex-col">
              <div className="p-4 border-b flex justify-between items-center bg-green-600 text-white">
                <h2 className="font-bold text-lg flex items-center gap-2"><MessageCircle size={20} /> Order Assistant</h2>
                <button onClick={() => setShowWASidebar(false)} className="p-2 hover:bg-white/10 rounded-full"><X size={24} /></button>
              </div>
              <div className="flex-1 overflow-hidden">
                <WhatsAppAssistant onOrderPlaced={() => setShowWASidebar(false)} />
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
