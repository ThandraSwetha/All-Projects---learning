import React from 'react';
import { BrowserRouter, Routes, Route, Link, useLocation } from 'react-router-dom';
import CustomerApp from './pages/CustomerApp';
import AdminDashboard from './pages/AdminDashboard';
import AdminLogin from './pages/AdminLogin';
import { Utensils, ChefHat, ShoppingBag } from 'lucide-react';

function Navigation() {
  const location = useLocation();
  const isAdmin = location.pathname.startsWith('/admin');

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white shadow-[0_2px_8px_rgba(0,0,0,0.08)] border-b border-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2.5 group">
            <div className="w-9 h-9 bg-zomato rounded-xl flex items-center justify-center shadow-md shadow-zomato/20 group-hover:shadow-zomato/40 transition-shadow">
              <Utensils size={18} className="text-white" />
            </div>
            <div className="flex flex-col leading-none">
              <span className="font-extrabold text-xl text-gray-900 tracking-tight">
                tiffin<span className="text-zomato">flow</span>
              </span>
              <span className="text-[10px] text-gray-400 font-medium tracking-wider uppercase">Smart Order Hub</span>
            </div>
          </Link>

          {/* Nav Links */}
          <div className="flex items-center gap-2">
            <Link
              to="/"
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition-all duration-200 ${
                !isAdmin
                  ? 'bg-zomato text-white shadow-md shadow-zomato/25'
                  : 'text-gray-500 hover:text-gray-800 hover:bg-gray-50'
              }`}
            >
              <ShoppingBag size={16} />
              <span className="hidden sm:inline">Order Food</span>
            </Link>
            <Link
              to="/admin/login"
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition-all duration-200 ${
                isAdmin
                  ? 'bg-gray-900 text-white shadow-md'
                  : 'text-gray-500 hover:text-gray-800 hover:bg-gray-50'
              }`}
            >
              <ChefHat size={16} />
              <span className="hidden sm:inline">Chef Panel</span>
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
}

function Footer() {
  return (
    <footer className="bg-gray-50 border-t border-gray-100 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-zomato rounded-lg flex items-center justify-center">
              <Utensils size={16} className="text-white" />
            </div>
            <span className="font-bold text-lg text-gray-800">
              tiffin<span className="text-zomato">flow</span>
            </span>
          </div>
          <div className="flex gap-6 text-sm text-gray-500">
            <span>WhatsApp Ordering</span>
            <span>•</span>
            <span>Smart Dashboard</span>
            <span>•</span>
            <span>Easy Payments</span>
          </div>
          <p className="text-sm text-gray-400">&copy; 2026 TiffinFlow. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}

function App() {
  return (
    <BrowserRouter>
      <div className="flex flex-col min-h-screen bg-white">
        <Navigation />
        <main className="flex-1 pt-16">
          <Routes>
            <Route path="/" element={<CustomerApp />} />
            <Route path="/admin/login" element={<AdminLogin />} />
            <Route path="/admin" element={<AdminDashboard />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </BrowserRouter>
  );
}

export default App;
