import React from 'react';

function OrderCard({ order, onMarkDelivered, onDelete }) {
  const isPending = order.status === 'Pending';

  return (
    <div className={`order-card ${isPending ? 'pending' : 'delivered'}`}>
      <div className="order-header">
        <div className="order-customer">
          <h3>{order.customerName}</h3>
          <p className="order-id">ID: {order._id?.slice(-6) || 'N/A'}</p>
        </div>
        <span className={`status-badge ${isPending ? 'pending' : 'delivered'}`}>
          {order.status}
        </span>
      </div>

      <div className="order-info">
        <div className="info-item">
          <span>📱</span>
          <span>{order.phone}</span>
        </div>
        <div className="info-item">
          <span>📍</span>
          <span>{order.address}</span>
        </div>
      </div>

      <div className="order-items">
        <p className="order-items-title">Order Details</p>
        {order.items?.map((item, idx) => (
          <div key={idx} className="item">
            <span className="item-name">{item.name}</span>
            <span className="item-qty">× {item.quantity}</span>
          </div>
        ))}
      </div>

      <div className="order-total">
        <p className="order-total-label">Total Amount</p>
        <p className="order-total-amount">₹ {order.totalAmount}</p>
      </div>

      <div className="order-actions">
        {isPending && (
          <button
            onClick={() => onMarkDelivered(order._id)}
            className="action-btn delivered"
          >
            ✓ Mark Delivered
          </button>
        )}
        <button
          onClick={() => onDelete(order._id)}
          className="action-btn delete"
        >
          🗑️ Delete
        </button>
      </div>
    </div>
  );
}

export default OrderCard;
