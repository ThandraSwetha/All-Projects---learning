import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import axios from 'axios';

const API_URL = 'https://foodorder-bxm6.onrender.com/api';

// WhatsApp green palette
const WA_GREEN = '#25D366';
const WA_DARK = '#075E54';
const WA_LIGHT_GREEN = '#DCF8C6';
const WA_BG = '#ECE5DD';

/* ─────────────────────────────────────────────
   Chat bubble helpers
───────────────────────────────────────────── */
function BotBubble({ children, delay = 0 }) {
  return (
    <motion.div
      initial={{ opacity: 0, x: -16 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay }}
      className="flex gap-2 mb-3"
    >
      <div className="w-8 h-8 rounded-full bg-white border-2 flex items-center justify-center text-base flex-shrink-0 shadow-sm"
        style={{ borderColor: WA_GREEN }}>
        🍱
      </div>
      <div className="max-w-[80%] bg-white rounded-2xl rounded-tl-none px-4 py-3 shadow-sm text-sm text-gray-800 leading-relaxed"
        style={{ borderTop: `3px solid ${WA_GREEN}` }}>
        {children}
      </div>
    </motion.div>
  );
}

function UserBubble({ children }) {
  return (
    <motion.div
      initial={{ opacity: 0, x: 16 }}
      animate={{ opacity: 1, x: 0 }}
      className="flex justify-end mb-3"
    >
      <div className="max-w-[75%] rounded-2xl rounded-tr-none px-4 py-3 text-sm text-gray-900 shadow-sm"
        style={{ background: WA_LIGHT_GREEN }}>
        {children}
      </div>
    </motion.div>
  );
}

/* ─────────────────────────────────────────────
   MAIN COMPONENT
───────────────────────────────────────────── */
export default function WhatsAppAssistant({ onOrderPlaced }) {
  const [messages, setMessages] = useState([]);
  const [inputText, setInputText] = useState('');
  const [step, setStep] = useState('idle'); // idle | greeting | menu | selecting | confirm | schedule | done
  const [menuItems, setMenuItems] = useState([]);
  const [cart, setCart] = useState([]); // [{ name, quantity, price }]
  const [customerPhone, setCustomerPhone] = useState(localStorage.getItem('customerPhone') || '');
  const [previousOrders, setPreviousOrders] = useState([]);
  const [scheduledTime, setScheduledTime] = useState('');
  const [isScheduling, setIsScheduling] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [suggestedUsual, setSuggestedUsual] = useState(null);
  const bottomRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    fetchMenu();
    if (customerPhone) fetchPreviousOrders(customerPhone);
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const fetchMenu = async () => {
    try {
      const res = await axios.get(`${API_URL}/menu-items`);
      setMenuItems(res.data.filter(i => i.available !== false));
    } catch (_) {}
  };

  const fetchPreviousOrders = async (phone) => {
    try {
      const res = await axios.get(`${API_URL}/orders/previous/${phone}`);
      if (res.data.length > 0) {
        setPreviousOrders(res.data);
        const last = res.data[0];
        setSuggestedUsual(last);
      }
    } catch (_) {}
  };

  const addBotMessage = (content, delay = 0) => {
    setTimeout(() => {
      setIsTyping(false);
      setMessages(prev => [...prev, { type: 'bot', content, id: Date.now() + Math.random() }]);
    }, delay);
  };

  const addUserMessage = (content) => {
    setMessages(prev => [...prev, { type: 'user', content, id: Date.now() + Math.random() }]);
  };

  const showTyping = (ms = 800) => {
    setIsTyping(true);
    return new Promise(r => setTimeout(() => { setIsTyping(false); r(); }, ms));
  };

  // ── Start the conversation ──
  const startConversation = async () => {
    setStep('greeting');
    addUserMessage('Hi');
    await showTyping(900);
    const customerName = localStorage.getItem('customerName') || 'there';

    addBotMessage(
      <div>
        <p>👋 Hello <strong>{customerName}</strong>! Welcome to <strong style={{ color: WA_DARK }}>TiffinFlow</strong> ordering.</p>
        <p className="mt-1 text-gray-500 text-xs">I'm your order assistant. Let me show you today's menu! 🍽️</p>
      </div>
    );

    await showTyping(1200);
    showMenuMessage();
  };

  // ── Show the interactive menu ──
  const showMenuMessage = () => {
    setStep('menu');

    const menuContent = (
      <div>
        <p className="font-bold mb-3" style={{ color: WA_DARK }}>📋 Today's Menu</p>
        <div className="space-y-2">
          {menuItems.slice(0, 6).map((item, idx) => (
            <div key={item._id}
              className="flex justify-between items-center p-2 rounded-lg bg-gray-50 hover:bg-green-50 cursor-pointer border border-transparent hover:border-green-200 transition-all"
              onClick={() => quickAddItem(item)}>
              <span className="text-sm font-medium">
                <span className="text-gray-400 mr-2">{idx + 1}.</span>
                {item.emoji || '🍛'} {item.name}
              </span>
              <span className="font-bold text-green-700 text-sm">₹{item.price}</span>
            </div>
          ))}
        </div>
        <p className="mt-3 text-xs text-gray-500">💡 Tap an item to add it, or type like <em>"2 dosa 1 idly"</em></p>
        {suggestedUsual && (
          <div className="mt-3 p-2 bg-green-50 rounded-xl border border-green-200">
            <p className="text-xs text-green-700 font-medium mb-1">🔄 Repeat your usual order?</p>
            <p className="text-xs text-gray-600">{suggestedUsual.items.map(i => `${i.quantity}x ${i.name}`).join(', ')}</p>
            <button
              onClick={() => repeatUsualOrder(suggestedUsual)}
              className="mt-1 text-xs font-bold px-3 py-1 rounded-lg text-white"
              style={{ background: WA_GREEN }}>
              ✓ Yes, repeat this
            </button>
          </div>
        )}
      </div>
    );

    addBotMessage(menuContent);
  };

  // ── Quick add item from menu tap ──
  const quickAddItem = (item) => {
    const newCart = [...cart];
    const existing = newCart.find(c => c.name === item.name);
    if (existing) {
      existing.quantity += 1;
    } else {
      newCart.push({ name: item.name, quantity: 1, price: item.price });
    }
    setCart(newCart);
    addUserMessage(`+ ${item.name}`);
    addBotMessage(
      <div>
        <p>✅ Added <strong>{item.name}</strong> to your order!</p>
        <p className="text-xs text-gray-500 mt-1">Cart: {newCart.map(i => `${i.quantity}x ${i.name}`).join(', ')}</p>
        <div className="mt-2 flex gap-2">
          <button onClick={() => proceedToConfirm(newCart)}
            className="text-xs font-bold px-3 py-1.5 rounded-lg text-white"
            style={{ background: WA_GREEN }}>
            ✓ Confirm Order
          </button>
          <button onClick={() => addMoreItem()}
            className="text-xs font-bold px-3 py-1.5 rounded-lg bg-gray-100 text-gray-700">
            + Add More
          </button>
        </div>
      </div>
    );
    setStep('selecting');
  };

  const addMoreItem = () => {
    addBotMessage(
      <div>
        <p>Sure! What else would you like to add?</p>
        <p className="text-xs text-gray-400 mt-1">Tap from the menu above or type your order.</p>
      </div>
    );
  };

  // ── Repeat usual order ──
  const repeatUsualOrder = (lastOrder) => {
    const newCart = lastOrder.items.map(i => ({
      name: i.name, quantity: i.quantity,
      price: menuItems.find(m => m.name.toLowerCase() === i.name.toLowerCase())?.price || 80,
    }));
    setCart(newCart);
    addUserMessage('✓ Yes, repeat my usual order');
    proceedToConfirm(newCart);
  };

  // ── Handle smart text messages ──
  const handleMessage = async (text) => {
    const low = text.toLowerCase().trim();
    addUserMessage(text);
    setInputText('');

    // Smart keyword detection
    if (low === 'hi' || low === 'hello' || low === 'hey' || step === 'idle') {
      await showTyping(700);
      startConversation();
      return;
    }

    if (low.includes('usual') || low.includes('same as yesterday') || low.includes('my usual')) {
      if (suggestedUsual) {
        await showTyping(600);
        addBotMessage(<p>📦 Got it! I found your usual order from last time.</p>);
        repeatUsualOrder(suggestedUsual);
      } else {
        await showTyping(600);
        addBotMessage(<p>🤔 I couldn't find any previous orders for your number. Let me show you the menu!</p>);
        showMenuMessage();
      }
      return;
    }

    if (low === 'cancel' || low === 'nevermind') {
      setCart([]);
      setStep('menu');
      await showTyping(500);
      addBotMessage(<p>❌ Order cancelled. Send <strong>Hi</strong> to start again!</p>);
      return;
    }

    if (low.includes('schedule') || low.includes('daily') || low.includes('every day') || low.includes('recurring')) {
      await showTyping(700);
      promptSchedule();
      return;
    }

    if (low.includes('pay') && previousOrders.some(o => o.paymentStatus === 'Pending')) {
      await showTyping(500);
      const pending = previousOrders.filter(o => o.paymentStatus === 'Pending');
      addBotMessage(
        <div>
          <p>💳 You have <strong>{pending.length}</strong> pending payment{pending.length > 1 ? 's' : ''}!</p>
          <p className="text-xs text-gray-500 mt-1">Total pending: ₹{pending.reduce((s, o) => s + o.totalAmount, 0)}</p>
          <button className="mt-2 text-xs font-bold px-3 py-1.5 rounded-lg text-white"
            style={{ background: '#f59e0b' }}>
            💰 Pay Now (UPI/Card)
          </button>
        </div>
      );
      return;
    }

    // Try to parse item quantities from text like "2 dosa 1 idly"
    const parsed = parseItemsFromText(low);
    if (parsed.length > 0) {
      const newCart = [...cart];
      parsed.forEach(p => {
        const existing = newCart.find(c => c.name.toLowerCase() === p.name.toLowerCase());
        if (existing) existing.quantity += p.quantity;
        else newCart.push(p);
      });
      setCart(newCart);
      await showTyping(600);
      addBotMessage(
        <div>
          <p>✅ Got it! Added to your order:</p>
          <ul className="mt-1 space-y-0.5 text-xs">
            {parsed.map((p, i) => <li key={i}>• {p.quantity}x {p.name} — ₹{p.price * p.quantity}</li>)}
          </ul>
          <div className="mt-2 flex gap-2">
            <button onClick={() => proceedToConfirm(newCart)}
              className="text-xs font-bold px-3 py-1.5 rounded-lg text-white"
              style={{ background: WA_GREEN }}>
              ✓ Confirm Order
            </button>
            <button onClick={() => showMenuMessage()}
              className="text-xs font-bold px-3 py-1.5 rounded-lg bg-gray-100 text-gray-700">
              + Add More
            </button>
          </div>
        </div>
      );
      setStep('selecting');
      return;
    }

    // Fallback
    await showTyping(600);
    addBotMessage(
      <div>
        <p>🤔 I didn't quite understand that. You can:</p>
        <ul className="mt-1 text-xs space-y-0.5 text-gray-600">
          <li>• Type <strong>Hi</strong> to see the menu</li>
          <li>• Type <strong>"2 dosa 1 idly"</strong> to add items</li>
          <li>• Type <strong>"usual"</strong> for your repeat order</li>
          <li>• Type <strong>"schedule"</strong> to set a daily order</li>
        </ul>
      </div>
    );
  };

  const parseItemsFromText = (text) => {
    const results = [];
    const regex = /(\d+)\s*([a-zA-Z\s]{2,})/g;
    let match;
    while ((match = regex.exec(text)) !== null) {
      const qty = parseInt(match[1]);
      const namePart = match[2].trim();
      const found = menuItems.find(m =>
        m.name.toLowerCase().includes(namePart) || namePart.includes(m.name.toLowerCase())
      );
      if (found) results.push({ name: found.name, quantity: qty, price: found.price });
    }
    return results;
  };

  // ── Confirm step ──
  const proceedToConfirm = (currentCart = cart) => {
    setStep('confirm');
    const total = currentCart.reduce((s, i) => s + i.price * i.quantity, 0);

    addBotMessage(
      <div>
        <p className="font-bold mb-3" style={{ color: WA_DARK }}>🧾 Order Summary</p>
        <div className="space-y-1.5 mb-3">
          {currentCart.map((item, idx) => (
            <div key={idx} className="flex justify-between text-sm">
              <span>{item.quantity}x {item.name}</span>
              <span className="font-bold">₹{item.price * item.quantity}</span>
            </div>
          ))}
        </div>
        <div className="border-t border-gray-200 pt-2 flex justify-between font-bold text-base">
          <span>Total</span>
          <span style={{ color: WA_DARK }}>₹{total}</span>
        </div>
        <div className="mt-3 flex gap-2">
          <button onClick={() => confirmOrder(currentCart, total)}
            className="flex-1 text-sm font-bold py-2 rounded-xl text-white shadow-md"
            style={{ background: WA_GREEN }}>
            ✅ Place Order
          </button>
          <button onClick={() => { setCart([]); setStep('menu'); showMenuMessage(); }}
            className="flex-1 text-sm font-bold py-2 rounded-xl bg-red-50 text-red-500">
            ❌ Cancel
          </button>
        </div>
      </div>
    );
  };

  // ── Schedule order ──
  const promptSchedule = () => {
    setStep('schedule');
    setIsScheduling(true);
    addBotMessage(
      <div>
        <p className="font-bold mb-2" style={{ color: WA_DARK }}>⏰ Schedule Daily Order</p>
        <p className="text-xs text-gray-500 mb-3">Pick a time for your recurring order every day.</p>
        <input
          type="time"
          defaultValue="08:00"
          onChange={e => setScheduledTime(e.target.value)}
          className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm mb-2 focus:outline-none"
          style={{ borderColor: WA_GREEN }}
        />
        <button onClick={() => confirmScheduledOrder()}
          className="w-full text-sm font-bold py-2 rounded-xl text-white"
          style={{ background: WA_GREEN }}>
          ⏰ Set Daily Order
        </button>
      </div>
    );
  };

  const confirmScheduledOrder = () => {
    if (cart.length === 0) {
      addBotMessage(<p>🛒 Add items first, then schedule! Send <strong>Hi</strong> to start.</p>);
      return;
    }
    const time = scheduledTime || '08:00';
    addUserMessage(`⏰ Schedule daily at ${time}`);
    placeOrder(cart, true, time);
  };

  // ── Final order placement ──
  const confirmOrder = (currentCart, total) => {
    addUserMessage('✅ Confirm order');
    placeOrder(currentCart, false, null, total);
  };

  const placeOrder = async (currentCart, isScheduled = false, recurringTime = null, total = null) => {
    const orderTotal = total || currentCart.reduce((s, i) => s + i.price * i.quantity, 0);
    const customerName = localStorage.getItem('customerName') || 'WhatsApp Customer';
    const phone = localStorage.getItem('customerPhone') || 'WA-Unknown';

    await showTyping(1000);

    try {
      const res = await axios.post(`${API_URL}/orders`, {
        customerName,
        phone,
        address: 'WhatsApp Order (Pickup / Call for Delivery)',
        items: currentCart.map(i => ({ name: i.name, quantity: i.quantity })),
        totalAmount: orderTotal,
        source: 'WhatsApp',
        paymentStatus: 'Pending',
        isScheduled,
        recurringTime,
      });

      setCart([]);
      setStep('done');
      setIsScheduling(false);

      if (onOrderPlaced) onOrderPlaced(res.data);

      addBotMessage(
        <div>
          <p className="font-bold text-green-700 text-base mb-1">
            {isScheduled ? '⏰ Daily Order Scheduled!' : '🎉 Order Placed Successfully!'}
          </p>
          <p className="text-xs text-gray-500 mb-2">
            Order #{res.data._id.substring(0, 8).toUpperCase()}
          </p>
          {isScheduled && (
            <p className="text-xs text-green-700 bg-green-50 rounded-lg px-3 py-1.5 mb-2">
              📅 Your food will be ordered every day at <strong>{recurringTime}</strong>
            </p>
          )}
          <div className="p-3 bg-yellow-50 rounded-xl border border-yellow-200 mb-2">
            <p className="text-xs font-bold text-yellow-800">💳 Payment Pending: ₹{orderTotal}</p>
            <p className="text-xs text-yellow-700 mt-0.5">Pay via UPI/Cash on delivery.</p>
          </div>
          <button
            onClick={() => { setStep('idle'); }}
            className="w-full mt-1 text-xs font-bold py-2 rounded-xl bg-gray-100 text-gray-600">
            🏠 Back to Start
          </button>
        </div>
      );
    } catch (err) {
      console.error(err);
      addBotMessage(<p>❌ Sorry, there was an error placing your order. Please try again!</p>);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (inputText.trim()) handleMessage(inputText.trim());
    }
  };

  const quickReplies = step === 'idle' || step === 'done'
    ? [{ label: '👋 Hi', action: () => handleMessage('Hi') }]
    : step === 'menu' || step === 'selecting'
    ? [
        { label: '✅ Confirm', action: () => proceedToConfirm() },
        { label: '🔄 Usual Order', action: () => handleMessage('usual') },
        { label: '⏰ Schedule', action: () => handleMessage('schedule') },
      ]
    : [];

  return (
    <div className="flex flex-col rounded-3xl overflow-hidden shadow-2xl border border-gray-200"
      style={{ background: WA_BG, height: '600px', maxHeight: '80vh' }}>

      {/* Header */}
      <div className="flex items-center gap-3 px-5 py-4 text-white"
        style={{ background: `linear-gradient(135deg, ${WA_DARK}, ${WA_GREEN})` }}>
        <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center text-xl">🍱</div>
        <div className="flex-1">
          <h3 className="font-bold text-base">TiffinFlow Assistant</h3>
          <p className="text-xs opacity-80">🟢 Online · Smart WhatsApp Ordering</p>
        </div>
        <div className="text-xs bg-white/20 px-2 py-1 rounded-full font-medium">WA Order</div>
      </div>

      {/* Chat messages */}
      <div className="flex-1 overflow-y-auto px-4 py-4"
        style={{ background: WA_BG }}>

        {/* Background watermark */}
        {messages.length === 0 && (
          <div className="flex flex-col items-center justify-center h-full text-center opacity-40">
            <div className="text-6xl mb-4">💬</div>
            <p className="font-bold text-gray-600 text-lg">Start a conversation!</p>
            <p className="text-gray-500 text-sm mt-1">Say <strong>Hi</strong> to see today's menu</p>
          </div>
        )}

        {messages.map((msg) => (
          msg.type === 'bot'
            ? <BotBubble key={msg.id}>{msg.content}</BotBubble>
            : <UserBubble key={msg.id}>{msg.content}</UserBubble>
        ))}

        {isTyping && (
          <div className="flex gap-2 mb-3">
            <div className="w-8 h-8 rounded-full bg-white border-2 flex items-center justify-center text-base flex-shrink-0"
              style={{ borderColor: WA_GREEN }}>🍱</div>
            <div className="bg-white rounded-2xl rounded-tl-none px-4 py-3 shadow-sm">
              <div className="flex gap-1 items-center h-4">
                {[0, 1, 2].map(i => (
                  <div key={i} className="w-2 h-2 rounded-full"
                    style={{
                      background: WA_GREEN,
                      animation: `bounce 1.2s infinite`,
                      animationDelay: `${i * 0.2}s`
                    }} />
                ))}
              </div>
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Quick reply chips */}
      {quickReplies.length > 0 && (
        <div className="flex gap-2 px-4 py-2 overflow-x-auto" style={{ background: 'rgba(255,255,255,0.7)' }}>
          {quickReplies.map((qr, i) => (
            <button key={i} onClick={qr.action}
              className="flex-shrink-0 text-xs font-bold px-3 py-1.5 rounded-full border-2 bg-white transition-all hover:text-white"
              style={{ borderColor: WA_GREEN, color: WA_DARK }}
              onMouseEnter={e => { e.target.style.background = WA_GREEN; e.target.style.color = 'white'; }}
              onMouseLeave={e => { e.target.style.background = 'white'; e.target.style.color = WA_DARK; }}>
              {qr.label}
            </button>
          ))}
        </div>
      )}

      {/* Input bar */}
      <div className="flex items-center gap-2 px-4 py-3 bg-white border-t border-gray-200">
        <input
          ref={inputRef}
          type="text"
          value={inputText}
          onChange={e => setInputText(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={step === 'idle' ? 'Type "Hi" to start ordering...' : 'Type your message...'}
          className="flex-1 px-4 py-2.5 rounded-full bg-gray-100 text-sm outline-none focus:ring-2 transition-all"
          style={{ '--tw-ring-color': WA_GREEN + '50' }}
        />
        <button
          onClick={() => { if (inputText.trim()) handleMessage(inputText.trim()); }}
          className="w-10 h-10 rounded-full flex items-center justify-center text-white flex-shrink-0 transition-transform active:scale-90"
          style={{ background: inputText.trim() ? WA_GREEN : '#CBD5E1' }}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
            <line x1="22" y1="2" x2="11" y2="13" />
            <polygon points="22 2 15 22 11 13 2 9 22 2" />
          </svg>
        </button>
      </div>

      <style>{`
        @keyframes bounce {
          0%, 60%, 100% { transform: translateY(0); }
          30% { transform: translateY(-6px); }
        }
      `}</style>
    </div>
  );
}
