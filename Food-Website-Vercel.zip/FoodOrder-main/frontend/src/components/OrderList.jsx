import React, { useState } from 'react';
import OrderCard from './OrderCard';

function OrderList({ orders, onMarkDelivered, onDelete, loading }) {
  const [filter, setFilter] = useState('All');

  const filteredOrders = orders.filter(order => {
    if (filter === 'Pending') return order.status === 'Pending';
    if (filter === 'Delivered') return order.status === 'Delivered';
    return true;
  });

  const pendingCount = orders.filter(o => o.status === 'Pending').length;
  const deliveredCount = orders.filter(o => o.status === 'Delivered').length;

  return (
    <div className="orders-section">
      <div className="orders-header">
        <h2>All Orders</h2>
        <div className="filter-buttons">
          {['All', 'Pending', 'Delivered'].map(status => (
            <button
              key={status}
              onClick={() => setFilter(status)}
              className={`filter-btn ${filter === status ? 'active' : ''}`}
            >
              {status}
              {status === 'Pending' && pendingCount > 0 && (
                <span className="badge">{pendingCount}</span>
              )}
              {status === 'Delivered' && deliveredCount > 0 && (
                <span className="badge">{deliveredCount}</span>
              )}
            </button>
          ))}
        </div>
      </div>

      {loading && (
        <div className="loading-spinner">
          <div className="spinner"></div>
          <p className="loading-text">Loading orders...</p>
        </div>
      )}

      {!loading && filteredOrders.length === 0 && (
        <div className="empty-state">
          <p className="empty-state-emoji">📭</p>
          <h3>No {filter.toLowerCase()} orders</h3>
          <p>
            {filter === 'All' ? 'Add a new order to get started!' : 'No orders in this category'}
          </p>
        </div>
      )}

      {!loading && filteredOrders.length > 0 && (
        <div className="orders-grid">
          {filteredOrders.map(order => (
            <OrderCard
              key={order._id}
              order={order}
              onMarkDelivered={onMarkDelivered}
              onDelete={onDelete}
            />
          ))}
        </div>
      )}
    </div>
  );
}

export default OrderList;
