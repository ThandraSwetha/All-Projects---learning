import React, { useState } from 'react';

function AddOrderForm({ onSubmit }) {
  const [form, setForm] = useState({
    customerName: '',
    phone: '',
    address: '',
    item: '',
    quantity: '',
    totalAmount: ''
  });
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!form.customerName || !form.phone || !form.address || !form.item || !form.quantity || !form.totalAmount) {
      alert('Please fill in all fields');
      return;
    }

    setLoading(true);
    await onSubmit(form);
    setLoading(false);
    
    // Reset form
    setForm({
      customerName: '',
      phone: '',
      address: '',
      item: '',
      quantity: '',
      totalAmount: ''
    });
  };

  return (
    <div className="form-card">
      <h2>➕ Add Order</h2>
      <p>Create a new food order</p>

      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Customer Name</label>
          <input
            type="text"
            name="customerName"
            placeholder="e.g., Rajesh Kumar"
            value={form.customerName}
            onChange={handleChange}
          />
        </div>

        <div className="form-group">
          <label>Phone Number</label>
          <input
            type="tel"
            name="phone"
            placeholder="98765-43210"
            value={form.phone}
            onChange={handleChange}
          />
        </div>

        <div className="form-group">
          <label>Delivery Address</label>
          <textarea
            name="address"
            placeholder="Enter full address"
            value={form.address}
            onChange={handleChange}
            rows="2"
          />
        </div>

        <div className="form-group">
          <label>Item Name</label>
          <input
            type="text"
            name="item"
            placeholder="e.g., Butter Dosa"
            value={form.item}
            onChange={handleChange}
          />
        </div>

        <div className="form-row">
          <div className="form-group">
            <label>Quantity</label>
            <input
              type="number"
              name="quantity"
              placeholder="1"
              value={form.quantity}
              onChange={handleChange}
            />
          </div>
          <div className="form-group">
            <label>Amount (₹)</label>
            <input
              type="number"
              name="totalAmount"
              placeholder="100"
              value={form.totalAmount}
              onChange={handleChange}
            />
          </div>
        </div>

        <button
          type="submit"
          disabled={loading}
          className="submit-btn"
        >
          {loading ? 'Creating Order...' : '+ Create Order'}
        </button>
      </form>
    </div>
  );
}

export default AddOrderForm;

