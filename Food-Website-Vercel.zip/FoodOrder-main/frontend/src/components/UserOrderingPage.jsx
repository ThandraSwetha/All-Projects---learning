import React, { useState, useEffect } from 'react';

const UserOrderingPage = ({ onOrderPlaced }) => {
  const [menuItems, setMenuItems] = useState([]);
  const [cart, setCart] = useState([]);
  const [loading, setLoading] = useState(true);
  const [customerInfo, setCustomerInfo] = useState({
    name: '',
    phone: '',
    address: ''
  });
  const [submitting, setSubmitting] = useState(false);
  const [message, setMessage] = useState('');

  // Fetch menu items on component mount
  useEffect(() => {
    fetchMenuItems();
  }, []);

  const fetchMenuItems = async () => {
    try {
      setLoading(true);
      const response = await fetch('https://foodorder-bxm6.onrender.com/api/menu-items');
      if (!response.ok) {
        // If API fails, use dummy menu items
        setMenuItems(getDummyMenuItems());
      } else {
        const data = await response.json();
        setMenuItems(data.length > 0 ? data : getDummyMenuItems());
      }
    } catch (error) {
      console.error('Error fetching menu items:', error);
      setMenuItems(getDummyMenuItems());
    } finally {
      setLoading(false);
    }
  };

  const getDummyMenuItems = () => [
    {
      _id: '1',
      name: 'Dosa',
      description: 'Crispy South Indian crepe with potato filling',
      price: 80,
      category: 'South Indian',
      image: '🥘'
    },
    {
      _id: '2',
      name: 'Idly',
      description: 'Soft steamed rice cakes',
      price: 60,
      category: 'South Indian',
      image: '🍚'
    },
    {
      _id: '3',
      name: 'Vada',
      description: 'Crispy lentil fritters',
      price: 50,
      category: 'South Indian',
      image: '🍩'
    },
    {
      _id: '4',
      name: 'Uttapam',
      description: 'Thick rice pancake with toppings',
      price: 90,
      category: 'South Indian',
      image: '🥞'
    },
    {
      _id: '5',
      name: 'Chole Bhature',
      description: 'Chickpeas curry with fried bread',
      price: 120,
      category: 'North Indian',
      image: '🍛'
    },
    {
      _id: '6',
      name: 'Butter Chicken',
      description: 'Tender chicken in creamy tomato sauce',
      price: 250,
      category: 'North Indian',
      image: '🍗'
    },
    {
      _id: '7',
      name: 'Lassi',
      description: 'Creamy yogurt drink',
      price: 40,
      category: 'Beverages',
      image: '🥛'
    },
    {
      _id: '8',
      name: 'Gulab Jamun',
      description: 'Sweet milk solids in sugar syrup',
      price: 70,
      category: 'Desserts',
      image: '🍮'
    }
  ];

  const addToCart = (item) => {
    const existingItem = cart.find(c => c._id === item._id);
    if (existingItem) {
      setCart(cart.map(c =>
        c._id === item._id
          ? { ...c, quantity: c.quantity + 1 }
          : c
      ));
    } else {
      setCart([...cart, { ...item, quantity: 1 }]);
    }
  };

  const removeFromCart = (itemId) => {
    setCart(cart.filter(item => item._id !== itemId));
  };

  const updateQuantity = (itemId, newQuantity) => {
    if (newQuantity <= 0) {
      removeFromCart(itemId);
    } else {
      setCart(cart.map(item =>
        item._id === itemId ? { ...item, quantity: newQuantity } : item
      ));
    }
  };

  const calculateTotal = () => {
    return cart.reduce((total, item) => total + (item.price * item.quantity), 0);
  };

  const handleCustomerInfoChange = (e) => {
    const { name, value } = e.target;
    setCustomerInfo({
      ...customerInfo,
      [name]: value
    });
  };

  const handlePlaceOrder = async (e) => {
    e.preventDefault();

    if (!customerInfo.name || !customerInfo.phone || !customerInfo.address) {
      setMessage('⚠️ Please fill in all customer details');
      return;
    }

    if (cart.length === 0) {
      setMessage('⚠️ Please add items to cart');
      return;
    }

    try {
      setSubmitting(true);
      const orderData = {
        customerName: customerInfo.name,
        phone: customerInfo.phone,
        address: customerInfo.address,
        items: cart.map(item => ({
          name: item.name,
          quantity: item.quantity,
          price: item.price
        })),
        totalAmount: calculateTotal()
      };

      const response = await fetch('https://foodorder-bxm6.onrender.com/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(orderData)
      });

      if (response.ok) {
        setMessage('✅ Order placed successfully! Your food will be prepared soon.');
        setCart([]);
        setCustomerInfo({ name: '', phone: '', address: '' });
        if (onOrderPlaced) {
          onOrderPlaced();
        }
        setTimeout(() => setMessage(''), 3000);
      } else {
        setMessage('❌ Failed to place order. Please try again.');
      }
    } catch (error) {
      console.error('Error placing order:', error);
      setMessage('❌ Error placing order. Check your connection.');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return <div className="loading-spinner">Loading menu...</div>;
  }

  return (
    <div className="user-ordering-container">
      <div className="ordering-header">
        <h1>🍽️ Order Your Food</h1>
        <p>Select items, enter details, and place your order</p>
      </div>

      <div className="ordering-content">
        {/* Menu Items Section */}
        <div className="menu-section">
          <h2>Available Items</h2>
          <div className="menu-grid">
            {menuItems.map(item => (
              <div key={item._id} className="menu-item-card">
                <div className="menu-item-image">{item.image}</div>
                <h3>{item.name}</h3>
                <p className="menu-item-description">{item.description}</p>
                <div className="menu-item-footer">
                  <span className="menu-item-price">₹{item.price}</span>
                  <button
                    className="add-to-cart-btn"
                    onClick={() => addToCart(item)}
                  >
                    Add to Cart
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Cart & Order Form Section */}
        <div className="cart-section">
          <div className="cart-card">
            <h2>🛒 Your Cart</h2>

            {cart.length === 0 ? (
              <p className="empty-cart">Your cart is empty</p>
            ) : (
              <>
                <div className="cart-items">
                  {cart.map(item => (
                    <div key={item._id} className="cart-item">
                      <div className="cart-item-info">
                        <h4>{item.name}</h4>
                        <p>₹{item.price} each</p>
                      </div>
                      <div className="cart-item-controls">
                        <button
                          className="qty-btn"
                          onClick={() => updateQuantity(item._id, item.quantity - 1)}
                        >
                          −
                        </button>
                        <span className="qty-display">{item.quantity}</span>
                        <button
                          className="qty-btn"
                          onClick={() => updateQuantity(item._id, item.quantity + 1)}
                        >
                          +
                        </button>
                      </div>
                      <span className="cart-item-total">₹{item.price * item.quantity}</span>
                      <button
                        className="remove-btn"
                        onClick={() => removeFromCart(item._id)}
                      >
                        ✕
                      </button>
                    </div>
                  ))}
                </div>

                <div className="cart-summary">
                  <div className="summary-row">
                    <span>Subtotal:</span>
                    <span>₹{calculateTotal()}</span>
                  </div>
                  <div className="summary-row">
                    <span>Delivery:</span>
                    <span>Free</span>
                  </div>
                </div>

                <div className="cart-total">
                  <h3>Total: ₹{calculateTotal()}</h3>
                </div>
              </>
            )}

            {/* Customer Info Form */}
            <form onSubmit={handlePlaceOrder} className="customer-form">
              <h3>📍 Delivery Details</h3>

              <div className="form-group">
                <label>Full Name</label>
                <input
                  type="text"
                  name="name"
                  value={customerInfo.name}
                  onChange={handleCustomerInfoChange}
                  placeholder="Enter your name"
                  required
                />
              </div>

              <div className="form-group">
                <label>Phone Number</label>
                <input
                  type="tel"
                  name="phone"
                  value={customerInfo.phone}
                  onChange={handleCustomerInfoChange}
                  placeholder="Enter your phone"
                  required
                />
              </div>

              <div className="form-group">
                <label>Delivery Address</label>
                <textarea
                  name="address"
                  value={customerInfo.address}
                  onChange={handleCustomerInfoChange}
                  placeholder="Enter your delivery address"
                  rows="3"
                  required
                />
              </div>

              {message && <div className="message-alert">{message}</div>}

              <button
                type="submit"
                className="place-order-btn"
                disabled={submitting || cart.length === 0}
              >
                {submitting ? 'Placing Order...' : 'Place Order'}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserOrderingPage;
