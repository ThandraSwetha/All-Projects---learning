import React from 'react';

function Header({ totalOrders, pendingOrders, deliveredOrders }) {
  return (
    <div className="header">
      <div className="header-content">
        <h1>📊 Order Dashboard</h1>
        <p>Manage all your daily food orders in one place</p>
        
        <div className="stats-container">
          <div className="stat-card">
            <h3>Total Orders</h3>
            <p className="number">{totalOrders}</p>
          </div>
          <div className="stat-card">
            <h3>Pending</h3>
            <p className="number" style={{ color: '#ffc107' }}>{pendingOrders}</p>
          </div>
          <div className="stat-card">
            <h3>Delivered</h3>
            <p className="number" style={{ color: '#4caf50' }}>{deliveredOrders}</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Header;
