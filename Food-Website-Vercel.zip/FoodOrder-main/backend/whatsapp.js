require('dotenv').config();
const twilio = require('twilio');

async function sendWhatsApp(toPhone, message) {
  try {
    console.log('Attempting to send WhatsApp to:', toPhone);
    console.log('TWILIO_SID:', process.env.TWILIO_SID);
    console.log('Token exists:', !!process.env.TWILIO_TOKEN);

    const client = twilio(process.env.TWILIO_SID, process.env.TWILIO_TOKEN);

    const result = await client.messages.create({
      from: 'whatsapp:+14155238886',
      to: `whatsapp:+91${toPhone}`,
      body: message
    });

    console.log('WhatsApp sent successfully! SID:', result.sid);
  } catch (err) {
    console.error('WhatsApp FAILED. Full error:', err);
  }
}

module.exports = { sendWhatsApp };
