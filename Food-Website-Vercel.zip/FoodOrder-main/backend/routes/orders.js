const express = require('express');
const Order = require('../models/order');
const { sendWhatsApp } = require('../whatsapp');


const router = express.Router();

// POST / - Create a new order
router.post('/', async (req, res) => {
  try {
    const {
      customerName, phone, address, items, totalAmount,
      source, paymentStatus, isScheduled, recurringTime
    } = req.body;

    // Sanitize phone: keep only the last 10 digits
    const cleanPhone = phone.replace(/\D/g, '').slice(-10);

    const order = new Order({
      customerName,
      phone: cleanPhone,
      address,
      items,
      totalAmount,
      source: source || 'Web',
      paymentStatus: paymentStatus || 'Pending',
      isScheduled: isScheduled || false,
      recurringTime: recurringTime || null,
    });

    const savedOrder = await order.save();

    // Send WhatsApp Confirmation
    console.log('Customer phone from order:', cleanPhone);
    const itemList = items.map(i => `• ${i.name} x${i.quantity}`).join('\n');
    await sendWhatsApp(cleanPhone, 
      `Hi ${customerName}! Your TiffinFlow order is confirmed!\n\n${itemList}\n\nTotal: ₹${totalAmount}\n\nWe will notify you when it is ready!`
    );

    res.status(201).json(savedOrder);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// GET / - Fetch all orders sorted by latest
router.get('/', async (req, res) => {
  try {
    const orders = await Order.find().sort({ createdAt: -1 });
    res.json(orders);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// GET /previous/:phone - Fetch previous orders for a phone number (for WhatsApp "usual order")
router.get('/previous/:phone', async (req, res) => {
  try {
    const orders = await Order.find({ phone: req.params.phone })
      .sort({ createdAt: -1 })
      .limit(5);
    res.json(orders);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// PUT /:id - Update order status / payment
router.put('/:id', async (req, res) => {
  try {
    const updates = {};
    if (req.body.status !== undefined) updates.status = req.body.status;
    if (req.body.paymentStatus !== undefined) updates.paymentStatus = req.body.paymentStatus;
    if (req.body.deliveryBatch !== undefined) updates.deliveryBatch = req.body.deliveryBatch;
    if (req.body.paymentReminder !== undefined) updates.paymentReminder = req.body.paymentReminder;

    const order = await Order.findByIdAndUpdate(
      req.params.id,
      { $set: updates },
      { new: true, runValidators: true }
    );

    if (!order) {
      return res.status(404).json({ error: 'Order not found' });
    }

    res.json(order);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// PUT /batch/status - Update multiple orders at once (batch delivery)
router.put('/batch/status', async (req, res) => {
  try {
    const { orderIds, status, deliveryBatch } = req.body;

    if (!orderIds || !Array.isArray(orderIds) || orderIds.length === 0) {
      return res.status(400).json({ error: 'orderIds array is required' });
    }

    const updates = {};
    if (status) updates.status = status;
    if (deliveryBatch !== undefined) updates.deliveryBatch = deliveryBatch;

    await Order.updateMany(
      { _id: { $in: orderIds } },
      { $set: updates }
    );

    const updatedOrders = await Order.find({ _id: { $in: orderIds } });
    res.json({ success: true, orders: updatedOrders });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// DELETE /:id - Delete an order
router.delete('/:id', async (req, res) => {
  try {
    const order = await Order.findByIdAndDelete(req.params.id);

    if (!order) {
      return res.status(404).json({ error: 'Order not found' });
    }

    res.json({ message: 'Order deleted successfully', order });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// POST /whatsapp/convert - Convert WhatsApp message to order
router.post('/whatsapp/convert', async (req, res) => {
  try {
    const { message, customerName, phone, address } = req.body;

    if (!message || !customerName || !phone || !address) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const items = [];
    const itemRegex = /(\d+)\s+([a-zA-Z\s]+)/gi;
    let match;
    let totalAmount = 0;

    const menuPrices = {
      'idly': 60, 'dosa': 80, 'vada': 50, 'uttapam': 90,
      'sambar': 70, 'chutney': 30, 'paneer tikka': 180,
      'butter chicken': 250, 'dal makhani': 140, 'naan': 40,
      'lassi': 40, 'chai': 30, 'meals': 120, 'biryani': 150,
    };

    while ((match = itemRegex.exec(message)) !== null) {
      const quantity = parseInt(match[1]);
      const itemName = match[2].trim().toLowerCase();
      const price = menuPrices[itemName] || 100;

      items.push({ name: itemName, quantity, price });
      totalAmount += price * quantity;
    }

    if (items.length === 0) {
      return res.status(400).json({ error: 'Could not parse items from message' });
    }

    const order = new Order({
      customerName,
      phone,
      address,
      items,
      totalAmount,
      source: 'WhatsApp',
      paymentStatus: 'Pending',
      status: 'New'
    });

    await order.save();

    res.status(201).json({
      success: true,
      message: 'WhatsApp order created successfully',
      order
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// GET /stats/dashboard - Get order statistics
router.get('/stats/dashboard', async (req, res) => {
  try {
    const stats = {
      new: await Order.countDocuments({ status: 'New' }),
      preparing: await Order.countDocuments({ status: 'Preparing' }),
      outForDelivery: await Order.countDocuments({ status: 'Out for Delivery' }),
      completed: await Order.countDocuments({ status: 'Completed' }),
      totalRevenue: 0
    };

    const orders = await Order.find({ status: 'Completed' });
    stats.totalRevenue = orders.reduce((sum, order) => sum + order.totalAmount, 0);

    res.json(stats);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// PATCH /:id/status - Update status and notify via WhatsApp
router.patch('/:id/status', async (req, res) => {
  try {
    const { status } = req.body;
    const order = await Order.findByIdAndUpdate(
      req.params.id,
      { $set: { status } },
      { new: true }
    );

    if (!order) return res.status(404).json({ error: 'Order not found' });

    // Status Notifications
    if (status === 'Preparing') {
      await sendWhatsApp(order.phone,
        `Hi ${order.customerName}! Your TiffinFlow order is now being prepared. Ready in 30 mins!`
      );
    }
    if (status === 'Delivered') {
      await sendWhatsApp(order.phone,
        `Hi ${order.customerName}! Your order has been delivered. Enjoy your meal! Please rate us here: https://yoursite.com/rate/${order._id}`
      );
    }

    res.json(order);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;

