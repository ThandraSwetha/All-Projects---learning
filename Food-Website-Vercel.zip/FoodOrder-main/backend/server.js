require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const { handleIncomingMessage } = require('./whatsappBot');

let ordersRouter;
let menuItemsRouter;
let authRouter;
try {
  ordersRouter = require('./routes/orders');
  console.log('✓ Orders router loaded successfully');
} catch (error) {
  console.error('✗ Failed to load orders router:', error.message);
  process.exit(1);
}

try {
  menuItemsRouter = require('./routes/menuItems');
  console.log('✓ Menu Items router loaded successfully');
} catch (error) {
  console.error('✗ Failed to load menu items router:', error.message);
  process.exit(1);
}

try {
  authRouter = require('./routes/auth');
  console.log('✓ Auth router loaded successfully');
} catch (error) {
  console.error('✗ Failed to load auth router:', error.message);
  process.exit(1);
}

const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// MongoDB Connection
const mongoURI = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/food-order-manager';

mongoose.connect(mongoURI)
  .then(() => console.log("MongoDB connected"))
  .catch(err => console.log("MongoDB connection error:", err));

// Basic GET route
app.get('/', (req, res) => {
  res.json({ message: 'API is running' });
});

// Order routes
app.use('/api/orders', ordersRouter);
console.log('✓ Order routes registered at /api/orders');

// Menu Items routes
app.use('/api/menu-items', menuItemsRouter);
console.log('✓ Menu Items routes registered at /api/menu-items');

// Auth routes
app.use('/api/auth', authRouter);
console.log('✓ Auth routes registered at /api/auth');

// WhatsApp Webhook
app.post('/webhook/whatsapp', async (req, res) => {
  const from = req.body.From;
  const text = req.body.Body;
  console.log(`[Webhook] WhatsApp from ${from}: ${text}`);
  
  if (from && text) {
    await handleIncomingMessage(from, text);
  }
  
  res.status(200).send('OK');
});
console.log('✓ WhatsApp Webhook registered at /webhook/whatsapp');

// Initialize automated reporting service
require('./services/ReportService');
console.log('✓ Daily report cron job initialized (9:00 PM)');

// Debug endpoint to verify server is working
app.get('/debug', (req, res) => {
  res.json({ 
    status: 'Server running',
    mongooseConnected: mongoose.connection.readyState === 1,
    routesRegistered: !!ordersRouter && !!menuItemsRouter && !!authRouter
  });
});

// Temporary Seed Route
app.get('/api/seed', async (req, res) => {
  try {
    const MenuItem = require('./models/menuItem');
    await MenuItem.deleteMany({});
    await MenuItem.insertMany([
      { name: 'Idly', price: 40, category: 'Tiffins' },
      { name: 'Dosa', price: 60, category: 'Tiffins' },
      { name: 'Vada', price: 50, category: 'Tiffins' },
      { name: 'Uttapam', price: 70, category: 'Tiffins' },
      { name: 'Pongal', price: 60, category: 'Tiffins' },
      { name: 'Full Meals', price: 150, category: 'Meals' },
      { name: 'Mini Meals', price: 100, category: 'Meals' },
      { name: 'Roti Sabji', price: 90, category: 'Meals' },
      { name: 'Biryani', price: 220, category: 'Rice' },
      { name: 'Sambar Rice', price: 80, category: 'Rice' },
      { name: 'Curd Rice', price: 80, category: 'Rice' },
      { name: 'Lemon Rice', price: 90, category: 'Rice' }
    ]);
    res.json({ success: true, message: '12 items seeded!' });
  } catch(err) {
    res.json({ error: err.message });
  }
});

// Catch 404
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found', path: req.path });
});

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`✓ Server is running on port ${PORT}`);
  console.log(`Try: http://localhost:${PORT}/`);
  console.log(`Try: http://localhost:${PORT}/api/orders`);
  console.log(`Debug: http://localhost:${PORT}/debug`);
});
