const mongoose = require('mongoose');
const MenuItem = require('./models/menuItem');
require('dotenv').config();

const mongoURI = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/food-order-manager';

// Using pixabay CDN + wikimedia commons + direct permanent URLs
// that work without referrer headers

const menuItems = [
  // ─────────────────── TIFFINS ───────────────────
  {
    name: 'Idly',
    description: 'Soft steamed rice cakes served with coconut chutney & sambar. A classic South Indian breakfast.',
    price: 60,
    category: 'Tiffins',
    emoji: '🍚',
    image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a5/Idli_Sambar.jpg/800px-Idli_Sambar.jpg',
    rating: 4.5,
    reviews: 234,
    trending: true
  },
  {
    name: 'Dosa',
    description: 'Crispy golden masala dosa with spiced potato filling & chutneys. Paper-thin & perfectly roasted.',
    price: 80,
    category: 'Tiffins',
    emoji: '🥘',
    image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/Masala_dosa.jpg/800px-Masala_dosa.jpg',
    rating: 4.8,
    reviews: 456,
    trending: true
  },
  {
    name: 'Vada',
    description: 'Crispy golden medu vada – crunchy lentil fritters served with sambar & coconut chutney.',
    price: 50,
    category: 'Tiffins',
    emoji: '🍩',
    image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/36/Medu_vada.JPG/800px-Medu_vada.JPG',
    rating: 4.3,
    reviews: 187
  },
  {
    name: 'Uttapam',
    description: 'Thick rice pancake topped with onions, tomatoes & cilantro. Soft inside, golden outside.',
    price: 90,
    category: 'Tiffins',
    emoji: '🥞',
    image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/4f/Uttapam.JPG/800px-Uttapam.JPG',
    rating: 4.2,
    reviews: 128
  },
  {
    name: 'Pongal',
    description: 'Creamy rice & lentil porridge tempered with ghee, pepper & cashews. Warm & comforting.',
    price: 70,
    category: 'Tiffins',
    emoji: '🫕',
    image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/d/d5/Pongal_festival_food.jpg/800px-Pongal_festival_food.jpg',
    rating: 4.4,
    reviews: 156
  },

  // ─────────────────── MEALS ───────────────────
  {
    name: 'Full Meals',
    description: 'Traditional thali – rice, sambar, rasam, veggies, curd & papad. A complete South Indian feast.',
    price: 150,
    category: 'Meals',
    emoji: '🍛',
    image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/40/South_Indian_meal.jpg/800px-South_Indian_meal.jpg',
    rating: 4.8,
    reviews: 567,
    trending: true
  },
  {
    name: 'Mini Meals',
    description: 'Quick satisfying lunch – rice, sambar and a fresh poriyal. Perfect for a light midday meal.',
    price: 100,
    category: 'Meals',
    emoji: '🍛',
    image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/40/South_Indian_meal.jpg/800px-South_Indian_meal.jpg',
    rating: 4.6,
    reviews: 345
  },
  {
    name: 'Roti Sabji',
    description: 'Fresh soft rotis with a homemade seasonal vegetable sabji. Wholesome & filling.',
    price: 90,
    category: 'Meals',
    emoji: '🍞',
    image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/6a/Roti_and_curry.jpg/800px-Roti_and_curry.jpg',
    rating: 4.4,
    reviews: 210
  },

  // ─────────────────── RICE ───────────────────
  {
    name: 'Biryani',
    description: 'Aromatic basmati rice slow-cooked with whole spices & tender chicken. Richly fragrant.',
    price: 220,
    category: 'Rice',
    emoji: '🍲',
    image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/9/94/Biryani_-_Kolkata_2011-08-14_00953.jpg/800px-Biryani_-_Kolkata_2011-08-14_00953.jpg',
    rating: 4.9,
    reviews: 899,
    trending: true
  },
  {
    name: 'Sambar Rice',
    description: 'Comfort bowl – fluffy rice mixed with tangy, spiced sambar. Soul food in a bowl.',
    price: 100,
    category: 'Rice',
    emoji: '🫕',
    image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a5/Idli_Sambar.jpg/800px-Idli_Sambar.jpg',
    rating: 4.4,
    reviews: 245
  },
  {
    name: 'Curd Rice',
    description: 'Chilled curd rice tempered with mustard seeds, curry leaves & pomegranate. Cooling & delicious.',
    price: 80,
    category: 'Rice',
    emoji: '🍚',
    image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/76/Curd_Rice.jpg/800px-Curd_Rice.jpg',
    rating: 4.6,
    reviews: 312
  },
  {
    name: 'Lemon Rice',
    description: 'Tangy lemon-tempered rice with peanuts, turmeric & curry leaves. Light & refreshing.',
    price: 90,
    category: 'Rice',
    emoji: '🍋',
    image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b3/Chitranna_or_Lemon_Rice.jpg/800px-Chitranna_or_Lemon_Rice.jpg',
    rating: 4.5,
    reviews: 198
  }
];

async function seedDatabase() {
  try {
    await mongoose.connect(mongoURI);
    console.log('✅ Connected to MongoDB');

    await MenuItem.deleteMany({});
    console.log('🗑️  Cleared existing menu items');

    const result = await MenuItem.insertMany(menuItems);
    console.log(`🌱 Seeded ${result.length} menu items successfully`);
    console.log('Items seeded:');
    result.forEach(i => console.log(`   • ${i.name} [${i.category}]`));

    await mongoose.connection.close();
    console.log('🔒 Database connection closed');
  } catch (error) {
    console.error('❌ Error seeding database:', error);
    process.exit(1);
  }
}

seedDatabase();
