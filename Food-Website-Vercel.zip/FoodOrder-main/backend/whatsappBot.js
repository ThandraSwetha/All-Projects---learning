require('dotenv').config();
const twilio = require('twilio');
const Order = require('./models/order');
const MenuItem = require('./models/menuItem');

const client = twilio(process.env.TWILIO_SID, process.env.TWILIO_TOKEN);
const sessions = {}; // stores conversation state per phone number

async function sendReply(to, message) {
  try {
    await client.messages.create({
      from: process.env.TWILIO_WHATSAPP_NUMBER || 'whatsapp:+14155238886',
      to: to,
      body: message
    });
    console.log(`WhatsApp reply sent to ${to}`);
  } catch (err) {
    console.error('WhatsApp Bot failed to send reply:', err.message);
  }
}

function parseItemsFromText(text, menuItems) {
  const results = [];
  const regex = /(\d+)\s*([a-zA-Z\s]{2,})/g;
  let match;
  while ((match = regex.exec(text)) !== null) {
    const qty = parseInt(match[1]);
    const namePart = match[2].trim().toLowerCase();
    const found = menuItems.find(m =>
      m.name.toLowerCase().includes(namePart) ||
      namePart.includes(m.name.toLowerCase())
    );
    if (found) results.push({ name: found.name, quantity: qty, price: found.price });
  }
  return results;
}

async function handleIncomingMessage(from, text) {
  const low = text.toLowerCase().trim();
  const session = sessions[from] || { step: 'start', cart: [] };
  sessions[from] = session;
  const menuItems = await MenuItem.find({});

  console.log(`[WA Bot] Processing message from ${from} in step: ${session.step}`);

  // STEP: START
  if (low === 'hi' || low === 'hello' || low === 'start' || session.step === 'start') {
    session.step = 'menu';
    const menuText = menuItems.map((m, i) =>
      `${i + 1}. ${m.name} - ₹${m.price}`
    ).join('\n');
    await sendReply(from,
      `Welcome to TiffinFlow! 🍱 Made with love by Mrs. Sharma\n\nToday's Menu:\n${menuText}\n\nType your order like:\n"2 dosa and 1 idly"`
    );
    return;
  }

  // STEP: PARSE ORDER
  if (session.step === 'menu') {
    const items = parseItemsFromText(text, menuItems);
    if (items.length === 0) {
      await sendReply(from,
        `Sorry I did not understand that. Please type like:\n"2 dosa and 1 idly"`
      );
      return;
    }
    session.cart = items;
    session.step = 'confirm';
    const total = items.reduce((s, i) => s + i.price * i.quantity, 0);
    const itemList = items.map(i => `• ${i.name} x${i.quantity} = ₹${i.price * i.quantity}`).join('\n');
    await sendReply(from,
      `Your order:\n${itemList}\n\nTotal: ₹${total}\n\nReply YES to confirm or NO to cancel`
    );
    return;
  }

  // STEP: CONFIRMATION
  if (session.step === 'confirm') {
    if (low === 'yes') {
      session.step = 'address';
      await sendReply(from,
        `Great! Please share your delivery address so we can deliver to you!`
      );
      return;
    }
    if (low === 'no') {
      session.step = 'menu';
      session.cart = [];
      await sendReply(from, `Order cancelled. Type Hi to start again!`);
      return;
    }
  }

  // STEP: GET ADDRESS
  if (session.step === 'address') {
    session.address = text;
    session.step = 'payment';
    await sendReply(from,
      `How would you like to pay?\n\n1. Cash on Delivery\n2. Online Payment (UPI/Card)\n\nReply 1 or 2`
    );
    return;
  }

  // STEP: PAYMENT
  if (session.step === 'payment') {
    const totalAmount = session.cart.reduce((s, i) => s + i.price * i.quantity, 0);
    const phoneNumber = from.replace('whatsapp:+91', '').replace('whatsapp:+', '');

    try {
      const order = await Order.create({
        customerName: `WhatsApp Customer`,
        phone: phoneNumber,
        items: session.cart,
        totalAmount: totalAmount,
        address: session.address,
        status: 'New',
        source: 'WhatsApp',
        paymentStatus: (low === '1' || low.includes('cash')) ? 'Pending' : 'Pending' // Both pending initially
      });

      if (low === '1' || low.includes('cash')) {
        await sendReply(from,
          `Order confirmed! 🎉\n\nPayment: Cash on Delivery\nTotal to pay: ₹${totalAmount}\n\nYour order is sent to Mrs. Sharma! We will notify you when it is ready. 👨🍳`
        );
      } else {
        await sendReply(from,
          `Order confirmed! 🎉\n\nPay here: http://localhost:3000/pay/${order._id}\n\nYour order is sent to Mrs. Sharma! We will notify you when it is ready. 👨🍳`
        );
      }

      session.step = 'start';
      session.cart = [];
    } catch (err) {
      console.error('Failed to create order from WhatsApp:', err);
      await sendReply(from, `Sorry, something went wrong while saving your order. Please try again later.`);
    }
    return;
  }

  // DEFAULT FALLBACK
  await sendReply(from, `Type Hi to start ordering! 🍱`);
}

module.exports = { handleIncomingMessage };
