const mongoose = require('mongoose');

const menuItemSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    unique: true
  },
  description: {
    type: String,
    default: ''
  },
  price: {
    type: Number,
    required: true
  },
  image: {
    type: String,
    default: ''
  },
  emoji: {
    type: String,
    default: '🍲'
  },
  category: {
    type: String,
    enum: ['Breakfast', 'Lunch', 'Dinner', 'Snacks', 'Beverages', 'Desserts', 'Tiffins', 'Meals', 'Rice'],
    default: 'Tiffins'
  },
  rating: {
    type: Number,
    default: 4.0
  },
  reviews: {
    type: Number,
    default: 0
  },
  available: {
    type: Boolean,
    default: true
  },
  trending: {
    type: Boolean,
    default: false
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('MenuItem', menuItemSchema);
