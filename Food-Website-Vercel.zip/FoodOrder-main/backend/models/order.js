const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
  customerName: {
    type: String,
    required: true,
  },
  phone: {
    type: String,
    required: true,
  },
  address: {
    type: String,
    required: true,
  },
  items: [
    {
      name: {
        type: String,
        required: true,
      },
      quantity: {
        type: Number,
        required: true,
      },
    },
  ],
  totalAmount: {
    type: Number,
    required: true,
  },
  status: {
    type: String,
    enum: ['New', 'Preparing', 'Cooking', 'Ready', 'Delivered'],
    default: 'New',
  },
  paymentStatus: {
    type: String,
    enum: ['Pending', 'Paid'],
    default: 'Pending',
  },
  source: {
    type: String,
    enum: ['Web', 'WhatsApp'],
    default: 'Web',
  },
  // WhatsApp enhancements
  isScheduled: {
    type: Boolean,
    default: false,
  },
  recurringTime: {
    type: String, // e.g. "08:00" for daily 8 AM
    default: null,
  },
  paymentReminder: {
    type: Boolean,
    default: false,
  },
  // Chef workflow enhancements
  deliveryBatch: {
    type: String,  // batch ID (e.g. uuid or timestamp)
    default: null,
  },
  rating: {
    type: Number,
    min: 1,
    max: 5,
    default: 5,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

module.exports = mongoose.model('Order', orderSchema);
