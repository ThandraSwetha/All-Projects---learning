const cron = require('node-cron');
const nodemailer = require('nodemailer');
const Order = require('../models/order');
const User = require('../models/user');

// Destination for the Daily Business Agent report
const REPORT_RECIPIENT = 'swethathandra65@gmail.com';

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

const TRANSLATIONS = {
  en: {
    subject: 'Daily TiffinFlow Report',
    title: 'Daily Business Summary',
    orders: 'Total Orders',
    revenue: 'Revenue',
    profit: 'Estimated Profit',
    topItems: 'Top Selling Items',
    rating: 'Average Rating',
    footer: 'TiffinFlow Business Agent'
  },
  te: {
    subject: 'రోజువారీ టిఫిన్ ఫ్లో నివేదిక',
    title: 'రోజువారీ వ్యాపార సారాంశం',
    orders: 'మొత్తం ఆర్డర్లు',
    revenue: 'ఆదాయం',
    profit: 'అంచనా వేసిన లాభం',
    topItems: 'ఎక్కువగా అమ్ముడైనవి',
    rating: 'సగటు రేటింగ్',
    footer: 'టిఫిన్ ఫ్లో బిజినెస్ ఏజెంట్'
  },
  hi: {
    subject: 'दैनिक टिफिनफ्लो रिपोर्ट',
    title: 'दैनिक व्यवसाय सारांश',
    orders: 'कुल ऑर्डर',
    revenue: 'राजस्व',
    profit: 'अनुमानित लाभ',
    topItems: 'सबसे अधिक बिकने वाले व्यंजन',
    rating: 'औसत रेटिंग',
    footer: 'टिफिनफ्लो बिजनेस एजेंट'
  }
};

const sendDailyReport = async () => {
  console.log('--- 🤖 11:00 PM REPORT AGENT STARTING... ---');
  
  const startOfDay = new Date();
  startOfDay.setHours(0, 0, 0, 0);
  const endOfDay = new Date();
  endOfDay.setHours(23, 59, 59, 999);

  try {
    // 1. Fetch Today's Orders
    const orders = await Order.find({
      createdAt: { $gte: startOfDay, $lte: endOfDay },
      status: 'Delivered'
    });

    if (orders.length === 0) {
      console.log('--- ⚠️ No orders marked "Delivered" today. Report will be empty! ---');
      // For this test, let's just use ALL today orders so the user can see the email!
      const anyOrders = await Order.find({ createdAt: { $gte: startOfDay } });
      if(anyOrders.length === 0) {
          console.log('--- 🛑 Zero orders found for today. Nothing to report. ---');
          return;
      }
      console.log('--- ℹ️ Using all today orders for test purposes. ---');
    }

    // 2. Data Processing
    let totalRevenue = 0;
    let totalRating = 0;
    const itemMap = {};

    const sourceData = orders.length > 0 ? orders : await Order.find({ createdAt: { $gte: startOfDay } });

    sourceData.forEach(order => {
      totalRevenue += order.totalAmount;
      totalRating += (order.rating || 5);
      order.items.forEach(item => {
        itemMap[item.name] = (itemMap[item.name] || 0) + item.quantity;
      });
    });

    const profit = totalRevenue * 0.4;
    const avgRating = (totalRating / sourceData.length).toFixed(1);
    const topItems = Object.entries(itemMap)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3)
      .map(([name]) => name);

    // 3. Language Detection
    const chef = await User.findOne({ email: REPORT_RECIPIENT }) || await User.findOne({ role: 'chef' });
    const lang = chef?.language || 'en';
    const t = TRANSLATIONS[lang] || TRANSLATIONS.en;

    // 4. Construct Email
    const emailBody = `
${t.title}
-----------------------------------
${t.orders}: ${sourceData.length}
${t.revenue}: ₹${totalRevenue}
${t.profit}: ₹${profit.toFixed(0)}
${t.topItems}: ${topItems.join(', ')}
${t.rating}: ${avgRating}/5

-----------------------------------
${t.footer}
    `;

    // 5. Send Mail
    await transporter.sendMail({
      from: `"TiffinFlow Agent" <${process.env.EMAIL_USER}>`,
      to: REPORT_RECIPIENT,
      subject: t.subject,
      text: emailBody
    });

    console.log(`--- ✅ SUCCESS: Report sent to ${REPORT_RECIPIENT} at ${new Date().toLocaleTimeString()} ---`);
  } catch (error) {
    console.error('--- ❌ ERROR: System failed to deliver email:', error.message);
  }
};

// CRON: 11:00 PM (23:00) for testing!
cron.schedule('0 23 * * *', sendDailyReport);

module.exports = { sendDailyReport };
